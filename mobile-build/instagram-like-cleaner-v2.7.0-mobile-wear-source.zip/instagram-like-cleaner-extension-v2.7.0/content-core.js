(() => {
  const CORE = {};

  CORE.normalize = (value) => String(value ?? '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

  CORE.rect = (element) => {
    if (!element?.isConnected || !element.getBoundingClientRect) return null;
    const own = element.getBoundingClientRect();
    if (own.width >= 4 && own.height >= 4) return own;
    const child = element.querySelector?.(
      'img, video, canvas, picture, [role="img"], svg'
    );
    const childRect = child?.getBoundingClientRect?.();
    return childRect && childRect.width >= 4 && childRect.height >= 4
      ? childRect
      : own;
  };

  CORE.visible = (element) => {
    const rect = CORE.rect(element);
    if (!rect || rect.width < 4 || rect.height < 4) return false;
    if (
      rect.bottom <= 0 ||
      rect.right <= 0 ||
      rect.top >= window.innerHeight ||
      rect.left >= window.innerWidth
    ) return false;

    const style = getComputedStyle(element);
    const opacity = style.opacity === '' ? 1 : Number.parseFloat(style.opacity);
    return (
      style.display !== 'none' &&
      style.visibility !== 'hidden' &&
      opacity !== 0 &&
      style.pointerEvents !== 'none'
    );
  };

  CORE.label = (element) => {
    if (!element) return '';
    const values = [
      element.getAttribute?.('aria-label'),
      element.getAttribute?.('title'),
      element.getAttribute?.('data-testid'),
      element.getAttribute?.('alt'),
      element.innerText,
      element.textContent
    ];

    const svg = element.matches?.('svg')
      ? element
      : element.querySelector?.('svg[aria-label], svg[title]');
    if (svg) {
      values.unshift(
        svg.getAttribute('aria-label'),
        svg.getAttribute('title')
      );
    }

    return CORE.normalize(values.filter(Boolean).join(' '));
  };

  CORE.exactLabel = (element, labels) => {
    const values = [
      element?.getAttribute?.('aria-label'),
      element?.getAttribute?.('title'),
      element?.innerText,
      element?.textContent
    ].filter(Boolean).map(CORE.normalize);

    return labels.some((label) => {
      const wanted = CORE.normalize(label);
      return values.some((value) => value === wanted);
    });
  };

  CORE.clickable = (element) => {
    if (!element) return null;
    return element.closest?.(
      'button, [role="button"], a, [tabindex="0"], [role="checkbox"]'
    ) || element;
  };

  CORE.actionElements = (doc = document) => {
    const nodes = [
      ...doc.querySelectorAll(
        'button, [role="button"], a[role="button"], [tabindex="0"]'
      )
    ];

    // Instagram sometimes places the text inside a span under a generic div.
    for (const span of doc.querySelectorAll('span')) {
      const text = CORE.normalize(span.textContent);
      if (
        text === '선택' ||
        text === 'select' ||
        text === '좋아요 취소' ||
        text === 'unlike'
      ) {
        const candidate = CORE.clickable(span);
        if (candidate) nodes.push(candidate);
      }
    }

    return [...new Set(nodes)].filter(CORE.visible);
  };

  CORE.findSelectButton = (doc = document) => {
    const labels = ['선택', 'select'];
    const candidates = CORE.actionElements(doc)
      .filter((element) => CORE.exactLabel(element, labels))
      .map((element) => {
        const rect = CORE.rect(element);
        let score = 0;
        if (element.matches('button')) score += 8;
        if (element.closest('main')) score += 6;
        if (rect.width >= 30 && rect.height >= 20) score += 3;
        if (rect.top < window.innerHeight * 0.5) score += 3;
        if (element.closest('[role="dialog"], [aria-modal="true"]')) score -= 20;
        return {element, score};
      })
      .sort((a, b) => b.score - a.score);

    return candidates[0]?.element || null;
  };

  CORE.findCancelSelectionButton = (doc = document) => {
    const labels = ['취소', 'cancel', '완료', 'done'];
    return CORE.actionElements(doc).find((element) => {
      if (!CORE.exactLabel(element, labels)) return false;
      if (element.closest('[role="dialog"], [aria-modal="true"]')) return false;
      const rect = CORE.rect(element);
      return rect.top < window.innerHeight * 0.55;
    }) || null;
  };

  CORE.selectionModeActive = (doc = document) => {
    if (CORE.findBulkUnlikeButton(doc)) return true;
    if (CORE.parseSelectedCount(doc) > 0) return true;
    if (CORE.findCancelSelectionButton(doc)) return true;

    const select = CORE.findSelectButton(doc);
    return !select && CORE.findGridCards(doc).length > 0;
  };

  CORE.mediaKey = (visual) => {
    const values = [
      visual.currentSrc,
      visual.src,
      visual.getAttribute?.('src'),
      visual.getAttribute?.('poster'),
      visual.getAttribute?.('alt'),
      visual.getAttribute?.('aria-label')
    ].filter(Boolean);

    if (values.length) return values.join('|');

    const rect = CORE.rect(visual);
    return rect
      ? `${Math.round(rect.left)}:${Math.round(rect.top)}:${Math.round(rect.width)}:${Math.round(rect.height)}`
      : '';
  };

  CORE.isPostHref = (href, base = location.href) => {
    if (!href) return true;

    try {
      const url = new URL(href, base);
      if (url.origin !== location.origin) return false;
      return (
        /^\/p\//.test(url.pathname) ||
        /^\/reel\//.test(url.pathname) ||
        /^\/tv\//.test(url.pathname) ||
        url.pathname === location.pathname
      );
    } catch {
      return false;
    }
  };

  CORE.findCardContainer = (visual, root) => {
    const visualRect = CORE.rect(visual);
    if (!visualRect) return visual;

    let best = visual;
    let node = visual;

    for (
      let depth = 0;
      node && node !== root && depth < 9;
      depth += 1, node = node.parentElement
    ) {
      const rect = CORE.rect(node);
      if (!rect) continue;

      const widthRatio = rect.width / Math.max(visualRect.width, 1);
      const heightRatio = rect.height / Math.max(visualRect.height, 1);
      const areaRatio =
        (rect.width * rect.height) /
        Math.max(visualRect.width * visualRect.height, 1);

      if (
        widthRatio <= 1.65 &&
        heightRatio <= 1.65 &&
        areaRatio <= 2.35
      ) {
        best = node;
      }

      if (
        node.matches?.(
          'a, button, [role="button"], [role="checkbox"], [tabindex="0"]'
        ) &&
        widthRatio <= 2.4 &&
        heightRatio <= 2.4 &&
        areaRatio <= 5.5
      ) {
        if (
          node.matches('a[href]') &&
          !CORE.isPostHref(node.getAttribute('href'))
        ) {
          continue;
        }
        return node;
      }
    }

    const outsideLink = best.closest?.('a[href]');
    if (
      outsideLink &&
      !CORE.isPostHref(outsideLink.getAttribute('href'))
    ) {
      return null;
    }

    return best;
  };

  CORE.findGridCards = (doc = document) => {
    const root =
      doc.querySelector('main') ||
      doc.querySelector('[role="main"]') ||
      doc.body;

    if (!root) return [];

    const rootRect = CORE.rect(root);
    const visualSelectors = [
      'img',
      'video',
      'canvas',
      '[role="img"]',
      '[style*="background-image"]'
    ].join(',');

    const raw = [...root.querySelectorAll(visualSelectors)]
      .filter((visual) => {
        if (!CORE.visible(visual)) return false;
        if (visual.closest('nav, header, footer, [role="dialog"], [aria-modal="true"]')) {
          return false;
        }

        const rect = CORE.rect(visual);
        if (!rect) return false;
        if (rect.width < 78 || rect.height < 78) return false;
        if (rect.width > 560 || rect.height > 560) return false;

        const ratio = rect.width / Math.max(rect.height, 1);
        if (ratio < 0.42 || ratio > 2.35) return false;

        if (rootRect) {
          const outside =
            rect.right <= rootRect.left ||
            rect.left >= rootRect.right ||
            rect.bottom <= rootRect.top ||
            rect.top >= rootRect.bottom;
          if (outside) return false;
        }

        // Ignore the fixed Instagram navigation rail and tiny profile assets.
        if (rect.right < Math.min(260, window.innerWidth * 0.18)) return false;
        return true;
      })
      .map((visual) => {
        const element = CORE.findCardContainer(visual, root);
        if (!element) return null;

        const outsideLink = element.closest?.('a[href]');
        if (
          outsideLink &&
          !CORE.isPostHref(outsideLink.getAttribute('href'))
        ) {
          return null;
        }

        const rect = CORE.rect(element) || CORE.rect(visual);
        return {
          element,
          visual,
          rect,
          key: CORE.mediaKey(visual)
        };
      })
      .filter(Boolean);

    // Prefer repeated grid-sized assets. This filters out logos and decorative images.
    const buckets = new Map();
    for (const item of raw) {
      const bucketKey = `${Math.round(item.rect.width / 30)}:${Math.round(item.rect.height / 30)}`;
      const group = buckets.get(bucketKey) || [];
      group.push(item);
      buckets.set(bucketKey, group);
    }

    const repeatedGroups = [...buckets.values()]
      .filter((group) => group.length >= 2)
      .sort((a, b) => {
        if (b.length !== a.length) return b.length - a.length;
        const aArea = a[0]?.rect
          ? a[0].rect.width * a[0].rect.height
          : 0;
        const bArea = b[0]?.rect
          ? b[0].rect.width * b[0].rect.height
          : 0;
        return bArea - aArea;
      });

    const dominant = repeatedGroups[0] || [];
    const source = dominant.length >= 2 ? dominant : raw;
    const seenKeys = new Set();
    const seenPositions = [];
    const cards = [];

    for (const item of source) {
      const position = {
        x: item.rect.left + item.rect.width / 2,
        y: item.rect.top + item.rect.height / 2
      };

      const overlaps = seenPositions.some((other) =>
        Math.abs(other.x - position.x) < 18 &&
        Math.abs(other.y - position.y) < 18
      );

      const key = item.key || `${Math.round(position.x)}:${Math.round(position.y)}`;
      if (overlaps || seenKeys.has(key)) continue;

      seenKeys.add(key);
      seenPositions.push(position);
      cards.push({...item, center: position});
    }

    return cards.sort((a, b) => {
      if (Math.abs(a.rect.top - b.rect.top) > 16) {
        return a.rect.top - b.rect.top;
      }
      return a.rect.left - b.rect.left;
    });
  };

  CORE.parseSelectedCount = (doc = document) => {
    const text = String(doc.body?.innerText || doc.body?.textContent || '');
    const patterns = [
      /([\d,.]+)\s*개\s*선택(?:됨)?/i,
      /선택(?:됨)?\s*([\d,.]+)\s*개?/i,
      /([\d,.]+)\s*(?:items?\s*)?selected/i,
      /selected\s*([\d,.]+)/i
    ];

    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match) {
        return Number(String(match[1]).replace(/[^0-9]/g, '')) || 0;
      }
    }

    return 0;
  };

  CORE.countSelectedMarkers = (doc = document) => {
    const selectors = [
      '[role="checkbox"][aria-checked="true"]',
      'input[type="checkbox"]:checked',
      '[aria-selected="true"]',
      '[data-state="checked"]',
      '[aria-label="선택됨"]',
      '[aria-label*="selected" i]'
    ];

    const nodes = [...doc.querySelectorAll(selectors.join(','))]
      .filter((node) => {
        if (!CORE.visible(node)) return false;
        if (node.closest('nav, header, footer')) return false;
        const rect = CORE.rect(node);
        return rect.width <= 120 && rect.height <= 120;
      });

    return new Set(nodes).size;
  };

  CORE.selectedCount = (doc = document) => {
    return Math.max(
      CORE.parseSelectedCount(doc),
      CORE.countSelectedMarkers(doc)
    );
  };

  CORE.findBulkUnlikeButton = (doc = document, options = {}) => {
    const labels = [
      '좋아요 취소',
      '선택한 항목 좋아요 취소',
      '좋아요 삭제',
      'unlike',
      'remove likes',
      'unlike selected'
    ];

    const dialogOnly = Boolean(options.dialogOnly);

    const candidates = CORE.actionElements(doc)
      .filter((element) => {
        const inDialog = Boolean(
          element.closest('[role="dialog"], [aria-modal="true"]')
        );
        if (dialogOnly && !inDialog) return false;

        const text = CORE.label(element);
        const matches = labels.some((label) => {
          const wanted = CORE.normalize(label);
          return text === wanted || text.includes(wanted);
        });
        if (!matches) return false;

        const rect = CORE.rect(element);
        const hasText = Boolean(element.innerText?.trim());
        return rect.width >= 68 || hasText;
      })
      .map((element) => {
        const rect = CORE.rect(element);
        let score = 0;
        if (element.closest('[role="dialog"], [aria-modal="true"]')) score += 20;
        if (element.matches('button')) score += 8;
        if (CORE.exactLabel(element, labels)) score += 10;
        if (rect.width >= 100) score += 4;
        if (rect.top > window.innerHeight * 0.45) score += 2;
        return {element, score};
      })
      .sort((a, b) => b.score - a.score);

    return candidates[0]?.element || null;
  };

  CORE.detectRestriction = (doc = document) => {
    const text = CORE.normalize(
      doc.body?.innerText || doc.body?.textContent || ''
    );
    const phrases = [
      'try again later',
      'action blocked',
      'we restrict certain activity',
      'we limit how often',
      '잠시 후 다시 시도',
      '활동이 차단',
      '일부 활동을 제한',
      '특정 활동을 제한',
      '요청을 처리하는 중 문제가 발생'
    ];

    return phrases.find((phrase) =>
      text.includes(CORE.normalize(phrase))
    ) || null;
  };

  globalThis.__INSTAGRAM_LIKE_CLEANER_CORE__ = CORE;
})();

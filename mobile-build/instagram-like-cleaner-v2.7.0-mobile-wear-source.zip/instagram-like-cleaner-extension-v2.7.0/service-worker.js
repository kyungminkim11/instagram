importScripts('plan-utils.js');
const PLAN = globalThis.__ILC_PLAN__;
const LIKES_URL='https://www.instagram.com/your_activity/interactions/likes/';
const JOB_KEY='instagramLikeCleanerNativeJobV12';
const COUNT_RESULT_KEY='instagramLikeCleanerCountResultV1';

const getJob=async()=>{const data=await chrome.storage.local.get(JOB_KEY);return data[JOB_KEY]||null;};
const getCountResult=async()=>{const data=await chrome.storage.local.get(COUNT_RESULT_KEY);return data[COUNT_RESULT_KEY]||null;};
const saveCountResult=async(result)=>{await chrome.storage.local.set({[COUNT_RESULT_KEY]:result});try{await chrome.runtime.sendMessage({type:'COUNT_RESULT_UPDATED',result});}catch{}return result;};
const saveJob=async(job)=>{await chrome.storage.local.set({[JOB_KEY]:job});try{await chrome.runtime.sendMessage({type:'NATIVE_JOB_UPDATED',job});}catch{}return job;};
const finalStatus=(result)=>result?.ok?'completed':result?.status==='blocked'?'blocked':result?.status==='stopped'?'stopped':'error';
const activeJob=(job)=>job&&['running','paused'].includes(job.status);

const normalizeConfig=(source={})=>({
  mode:['custom','rounds','all'].includes(source.mode)?source.mode:'custom',
  total:PLAN.sanitizeTotal(source.total),
  batchSize:Math.max(
    1,
    Math.min(
      PLAN.MAX_SELECTION,
      Math.floor(Number(source.batchSize)||20)
    )
  ),
  rounds:Math.max(1,Math.floor(Number(source.rounds)||10)),
  cooldownMs:PLAN.sanitizeCooldownMs(source.cooldownMs),
  autoScroll:source.autoScroll!==false,
  speed:PLAN.sanitizeSpeed({
    speedMode:source.speedMode,
    clickDelayMs:source.clickDelayMs,
    scrollWaitMs:source.scrollWaitMs
  })
});

const launchPlanJob=async({tabId,config,source='planner'})=>{
  const safe=normalizeConfig(config);
  const plan=PLAN.buildPlan(safe);
  const total=PLAN.sum(plan);
  const job={
    id:crypto.randomUUID(), mode:'delete_plan', strategyMode:safe.mode, source, tabId,
    plan, planTotal:total, deleteLimit:total, target:plan[0]||0, batchIndex:0,
    maxBatches:plan.length, cooldownMs:safe.cooldownMs,
    speedMode:safe.speed.id, clickDelayMs:safe.speed.clickDelayMs, scrollWaitMs:safe.speed.scrollWaitMs,
    selected:0, success:0, totalSuccess:0, failed:0, status:'running', phase:'preparing',
    createdAt:new Date().toISOString(), finishedAt:null,
    message:`${PLAN.describe({mode:safe.mode,plan,rounds:safe.rounds})} 방식으로 정리를 시작합니다.`
  };
  await saveJob(job);
  const accepted=await chrome.tabs.sendMessage(tabId,{type:'START_NATIVE_PLAN',options:{
    plan,
    cooldownMs:job.cooldownMs,
    autoScroll:safe.autoScroll,
    resetToTop:true,
    strategyMode:safe.mode,
    speedMode:safe.speed.id,
    clickDelayMs:safe.speed.clickDelayMs,
    scrollWaitMs:safe.speed.scrollWaitMs
  }});
  if(!accepted?.ok) return saveJob({...job,status:'error',phase:'finished',failed:1,finishedAt:new Date().toISOString(),message:accepted?.message||'Instagram 탭에서 정리 작업을 시작하지 못했습니다.'});
  return job;
};

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(!message?.type)return;

  if(message.type==='OPEN_LIKES_PAGE'){chrome.tabs.create({url:LIKES_URL,active:true}).then(tab=>sendResponse({ok:true,tabId:tab.id}));return true;}
  if(message.type==='GET_NATIVE_JOB'){getJob().then(job=>sendResponse({ok:true,job}));return true;}
  if(message.type==='GET_COUNT_RESULT'){getCountResult().then(result=>sendResponse({ok:true,result}));return true;}

  if(message.type==='START_COUNT_JOB'){
    (async()=>{
      const existing=await getJob(); if(activeJob(existing)){sendResponse({ok:false,message:'이미 진행 중인 작업이 있습니다.'});return;}
      const tabId=Number(message.tabId); if(!tabId){sendResponse({ok:false,message:'Instagram 좋아요 탭을 찾지 못했습니다.'});return;}
      const speed=PLAN.sanitizeSpeed({
        speedMode:message.speedMode,
        clickDelayMs:message.clickDelayMs,
        scrollWaitMs:message.scrollWaitMs
      });
      const job={id:crypto.randomUUID(),mode:'count',tabId,target:0,selected:0,counted:0,success:0,totalSuccess:0,status:'running',phase:'count_preparing',speedMode:speed.id,clickDelayMs:speed.clickDelayMs,scrollWaitMs:speed.scrollWaitMs,createdAt:new Date().toISOString(),finishedAt:null,message:`좋아요 게시물 전체 개수를 ${speed.label} 속도로 확인합니다.`};
      await saveJob(job);
      try{
        const accepted=await chrome.tabs.sendMessage(tabId,{
          type:'START_LIKED_COUNT',
          options:{
            restorePosition:true,
            maxPasses:650,
            speedMode:speed.id,
            clickDelayMs:speed.clickDelayMs,
            scrollWaitMs:speed.scrollWaitMs
          }
        });
        if(!accepted?.ok){const failed=await saveJob({...job,status:'error',phase:'finished',failed:1,finishedAt:new Date().toISOString(),message:accepted?.message||'개수 확인을 시작하지 못했습니다.'});sendResponse({ok:false,message:failed.message,job:failed});return;}
        sendResponse({ok:true,job});
      }catch(error){const failed=await saveJob({...job,status:'error',phase:'finished',failed:1,finishedAt:new Date().toISOString(),message:error?.message||'Instagram 탭과 통신하지 못했습니다.'});sendResponse({ok:false,message:failed.message,job:failed});}
    })();return true;
  }

  if(message.type==='START_DELETE_PLAN_JOB'){
    (async()=>{
      const tabId=Number(message.tabId); if(!tabId){sendResponse({ok:false,message:'Instagram 좋아요 탭을 찾지 못했습니다.'});return;}
      const config=normalizeConfig(message); const existing=await getJob();
      if(existing?.mode==='count'&&activeJob(existing)){
        try{
          const response=await chrome.tabs.sendMessage(existing.tabId,{type:'REQUEST_DELETE_COUNTED',options:config});
          if(!response?.ok){sendResponse({ok:false,message:response?.message||'개수 확인을 정리 작업으로 전환하지 못했습니다.'});return;}
          const actualTotal=Math.max(Number(response.counted)||0,Number(existing.counted)||0,config.total);
          const pendingConfig={...config,total:actualTotal};
          const updated=await saveJob({...existing,status:'running',phase:'count_handoff',pendingPlanConfig:pendingConfig,message:`현재까지 확인한 ${actualTotal.toLocaleString()}개를 정리 작업으로 전환합니다.`});
          sendResponse({ok:true,job:updated});
        }catch(error){sendResponse({ok:false,message:error?.message||'Instagram 탭과 통신하지 못했습니다.'});}
        return;
      }
      if(activeJob(existing)){sendResponse({ok:false,message:'다른 작업이 이미 진행 중입니다.'});return;}
      try{const job=await launchPlanJob({tabId,config,source:'planner'});if(job.status==='error'){sendResponse({ok:false,message:job.message,job});return;}sendResponse({ok:true,job});}
      catch(error){sendResponse({ok:false,message:error?.message||'정리 작업을 시작하지 못했습니다.'});}
    })();return true;
  }

  if(message.type==='START_DELETE_ALL_JOB'){
    (async()=>{
      const existing=await getJob();
      if(activeJob(existing)){
        sendResponse({ok:false,message:'다른 작업이 이미 진행 중입니다.'});
        return;
      }

      const tabId=Number(message.tabId);
      if(!tabId){
        sendResponse({ok:false,message:'Instagram 좋아요 탭을 찾지 못했습니다.'});
        return;
      }

      const batchSize=Math.max(
        1,
        Math.min(
          PLAN.MAX_SELECTION,
          Math.floor(Number(message.batchSize)||100)
        )
      );
      const cooldownMs=PLAN.sanitizeCooldownMs(message.cooldownMs);
      const speed=PLAN.sanitizeSpeed({
        speedMode:message.speedMode,
        clickDelayMs:message.clickDelayMs,
        scrollWaitMs:message.scrollWaitMs
      });
      const estimatedTotal=Math.max(
        0,
        Math.floor(Number(message.estimatedTotal)||0)
      );

      const job={
        id:crypto.randomUUID(),
        mode:'delete_all',
        strategyMode:'delete_all',
        source:'delete_all',
        tabId,
        batchSize,
        target:batchSize,
        batchIndex:0,
        maxBatches:0,
        cooldownMs,
        estimatedTotal,
        speedMode:speed.id,
        clickDelayMs:speed.clickDelayMs,
        scrollWaitMs:speed.scrollWaitMs,
        selected:0,
        success:0,
        totalSuccess:0,
        failed:0,
        status:'running',
        phase:'preparing',
        createdAt:new Date().toISOString(),
        finishedAt:null,
        message:`${batchSize}개씩 반복하며 좋아요가 없어질 때까지 전체 삭제합니다.`
      };

      await saveJob(job);

      try{
        const accepted=await chrome.tabs.sendMessage(tabId,{
          type:'START_NATIVE_DELETE_ALL',
          options:{
            batchSize,
            cooldownMs,
            autoScroll:message.autoScroll!==false,
            resetToTop:true,
            speedMode:speed.id,
            clickDelayMs:speed.clickDelayMs,
            scrollWaitMs:speed.scrollWaitMs
          }
        });

        if(!accepted?.ok){
          const failed=await saveJob({
            ...job,
            status:'error',
            phase:'finished',
            failed:1,
            finishedAt:new Date().toISOString(),
            message:accepted?.message||'Instagram 탭에서 전체 삭제를 시작하지 못했습니다.'
          });
          sendResponse({ok:false,message:failed.message,job:failed});
          return;
        }

        sendResponse({ok:true,job});
      }catch(error){
        const failed=await saveJob({
          ...job,
          status:'error',
          phase:'finished',
          failed:1,
          finishedAt:new Date().toISOString(),
          message:error?.message||'Instagram 탭과 통신하지 못했습니다.'
        });
        sendResponse({ok:false,message:failed.message,job:failed});
      }
    })();
    return true;
  }

  if(message.type==='LIKED_COUNT_PROGRESS'){
    (async()=>{const job=await getJob();if(!job||job.mode!=='count'||!activeJob(job)){sendResponse({ok:false});return;}const p=message.progress||{};const counted=Number(p.counted)||0;const updated=await saveJob({...job,phase:p.phase||job.phase,counted,selected:counted,message:p.message||job.message});sendResponse({ok:true,job:updated});})();return true;
  }

  if(message.type==='LIKED_COUNT_FINISHED'){
    (async()=>{
      const job=await getJob();if(!job||job.mode!=='count'){sendResponse({ok:false});return;}
      const result=message.result||{};const counted=Number(result.counted)||0;const complete=Boolean(result.complete);
      if(counted>0||result.ok)await saveCountResult({count:counted,exact:complete,checkedAt:new Date().toISOString(),status:result.status||(complete?'completed':'partial')});
      if(result.status==='handoff_delete'&&counted>0){
        try{const pending=job.pendingPlanConfig||result.deleteOptions||{};const config=normalizeConfig({...pending,total:counted});const launched=await launchPlanJob({tabId:job.tabId,config,source:'count_handoff'});sendResponse({ok:launched.status!=='error',job:launched});}
        catch(error){const failed=await saveJob({...job,status:'error',phase:'finished',counted,selected:counted,failed:1,finishedAt:new Date().toISOString(),message:error?.message||'개수 확인 결과를 정리 작업으로 전환하지 못했습니다.'});sendResponse({ok:false,job:failed});}
        return;
      }
      const updated=await saveJob({...job,status:job.status==='stopped'?'stopped':finalStatus(result),phase:'finished',counted,selected:counted,finishedAt:new Date().toISOString(),message:result.message||(complete?`좋아요 게시물은 총 ${counted.toLocaleString()}개입니다.`:`최소 ${counted.toLocaleString()}개를 확인했습니다.`)});
      sendResponse({ok:true,job:updated});
    })();return true;
  }

  if(message.type==='NATIVE_JOB_PROGRESS'){
    (async()=>{const job=await getJob();if(!job||!activeJob(job)){sendResponse({ok:false});return;}const p=message.progress||{};const updated=await saveJob({...job,phase:p.phase||job.phase,target:Number(p.target)||job.target||0,selected:Number(p.selected)||0,batchIndex:Number(p.batchIndex)||job.batchIndex||0,maxBatches:Number(p.maxBatches)||job.maxBatches||0,totalSuccess:Number(p.totalSuccess)||job.totalSuccess||0,success:Number(p.totalSuccess)||job.success||0,cooldownRemaining:Number(p.cooldownRemaining)||0,message:p.message||job.message});sendResponse({ok:true,job:updated});})();return true;
  }

  if(message.type==='NATIVE_JOB_FINISHED'){
    (async()=>{const job=await getJob();if(!job){sendResponse({ok:false});return;}const result=message.result||{};const totalSuccess=Number(result.totalSuccess??result.success)||job.totalSuccess||0;const updated=await saveJob({...job,status:job.status==='stopped'?'stopped':finalStatus(result),phase:'finished',selected:Number(result.selected)||0,batchIndex:Number(result.batchIndex)||job.batchIndex||0,success:totalSuccess,totalSuccess,failed:result.ok||result.status==='stopped'?0:1,finishedAt:new Date().toISOString(),message:result.message||`정리 작업을 종료했습니다. 총 ${totalSuccess.toLocaleString()}개를 정리했습니다.`});sendResponse({ok:true,job:updated});})();return true;
  }

  if(message.type==='PAUSE_NATIVE_JOB'){
    (async()=>{const job=await getJob();if(!job||job.status!=='running'){sendResponse({ok:false,message:'진행 중인 작업이 없습니다.'});return;}try{await chrome.tabs.sendMessage(job.tabId,{type:'PAUSE_NATIVE_JOB'});}catch{}const updated=await saveJob({...job,status:'paused',message:'작업을 일시정지했습니다.'});sendResponse({ok:true,job:updated});})();return true;
  }
  if(message.type==='RESUME_NATIVE_JOB'){
    (async()=>{const job=await getJob();if(!job||job.status!=='paused'){sendResponse({ok:false,message:'일시정지된 작업이 없습니다.'});return;}try{await chrome.tabs.sendMessage(job.tabId,{type:'RESUME_NATIVE_JOB'});}catch{}const updated=await saveJob({...job,status:'running',message:'작업을 재개했습니다.'});sendResponse({ok:true,job:updated});})();return true;
  }
  if(message.type==='STOP_NATIVE_JOB'){
    (async()=>{const job=await getJob();if(!job||!activeJob(job)){sendResponse({ok:false,message:'중단할 작업이 없습니다.'});return;}try{await chrome.tabs.sendMessage(job.tabId,{type:'STOP_NATIVE_JOB'});}catch{}const updated=await saveJob({...job,status:'stopped',phase:'finished',finishedAt:new Date().toISOString(),message:`작업을 중단했습니다. 누적 ${Number(job.totalSuccess)||0}개를 완료했습니다.`});sendResponse({ok:true,job:updated});})();return true;
  }
  if(message.type==='CLEAR_NATIVE_JOB'){chrome.storage.local.remove(JOB_KEY).then(()=>sendResponse({ok:true}));return true;}
});

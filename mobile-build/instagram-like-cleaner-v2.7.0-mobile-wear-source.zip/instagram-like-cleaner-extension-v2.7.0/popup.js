const $ = (id) => document.getElementById(id);
const PLAN = globalThis.__ILC_PLAN__;
const SETTINGS_KEY = 'instagramLikeCleanerPlannerSettingsV1';
const JOB_KEY = 'instagramLikeCleanerNativeJobV12';
const COUNT_RESULT_KEY = 'instagramLikeCleanerCountResultV1';

const ui = {
  openLikes: $('openLikes'), pageStatus: $('pageStatus'), selectStatus: $('selectStatus'), cardStatus: $('cardStatus'),
  startCount: $('startCount'), deleteCounted: $('deleteCounted'), likedCountResult: $('likedCountResult'), likedCountTime: $('likedCountTime'),
  cleanupTotal: $('cleanupTotal'), useCountResult: $('useCountResult'), strategyInputs: [...document.querySelectorAll('input[name="strategy"]')],
  customFields: $('customFields'), roundFields: $('roundFields'), cooldownFields: $('cooldownFields'), allWarning: $('allWarning'),
  batchSize: $('batchSize'), roundCount: $('roundCount'), cooldownSeconds: $('cooldownSeconds'), presetButtons: [...document.querySelectorAll('.presetButton')],
  speedInputs: [...document.querySelectorAll('input[name="speedMode"]')],
  customSpeedFields: $('customSpeedFields'), clickDelayMs: $('clickDelayMs'), scrollWaitMs: $('scrollWaitMs'),
  speedDescription: $('speedDescription'),
  autoScroll: $('autoScroll'), planDescription: $('planDescription'), confirmationCount: $('confirmationCount'), estimatedTime: $('estimatedTime'),
  startPlannedDelete: $('startPlannedDelete'),
  deleteAllBatchSize: $('deleteAllBatchSize'),
  deleteAllCooldownSeconds: $('deleteAllCooldownSeconds'),
  deleteAllBatchPresets: [...document.querySelectorAll('.deleteAllBatchPreset')],
  deleteAllCooldownPresets: [...document.querySelectorAll('.deleteAllCooldownPreset')],
  deleteAllPlan: $('deleteAllPlan'),
  deleteAllTime: $('deleteAllTime'),
  startDeleteAll: $('startDeleteAll'),
  jobStatus: $('jobStatus'), progress: $('progress'), batchCount: $('batchCount'),
  targetCount: $('targetCount'), selectedCount: $('selectedCount'), successCount: $('successCount'), message: $('message'),
  pause: $('pause'), stop: $('stop'), clear: $('clear')
};

let currentJob = null;
let lastCountResult = null;
let targetTouched = false;

const setMessage = (text, error = false) => {
  ui.message.textContent = text || '';
  ui.message.classList.toggle('is-error', Boolean(error));
};

const getActiveTab = async () => {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  return tab || null;
};

const selectedMode = () => ui.strategyInputs.find((input) => input.checked)?.value || 'custom';
const selectedSpeedMode = () => ui.speedInputs.find((input) => input.checked)?.value || 'balanced';

const speedConfig = () => PLAN.sanitizeSpeed({
  speedMode: selectedSpeedMode(),
  clickDelayMs: Number(ui.clickDelayMs.value),
  scrollWaitMs: Number(ui.scrollWaitMs.value)
});
const currentCount = () => {
  if (currentJob?.mode === 'count') return Math.max(Number(currentJob.counted)||0, Number(currentJob.selected)||0);
  return Number(lastCountResult?.count)||0;
};

const syncPresetButtons = () => {
  const cooldown = String(Math.round(Number(ui.cooldownSeconds.value) || 0));
  ui.presetButtons.forEach((button) => {
    const selected = button.dataset.seconds === cooldown;
    button.classList.toggle('is-selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });

  const deleteBatch = String(Math.round(Number(ui.deleteAllBatchSize.value) || 0));
  ui.deleteAllBatchPresets.forEach((button) => {
    const selected = button.dataset.value === deleteBatch;
    button.classList.toggle('is-selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });

  const deleteCooldown = String(Math.round(Number(ui.deleteAllCooldownSeconds.value) || 0));
  ui.deleteAllCooldownPresets.forEach((button) => {
    const selected = button.dataset.value === deleteCooldown;
    button.classList.toggle('is-selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
};

const planConfig = (totalOverride = null) => {
  const total = PLAN.sanitizeTotal(totalOverride ?? ui.cleanupTotal.value);
  const mode = selectedMode();
  const cooldownMs = PLAN.sanitizeCooldownMs(
    Number(ui.cooldownSeconds.value) * 1000
  );
  const batchSize = Math.max(
    1,
    Math.min(
      PLAN.MAX_SELECTION,
      Math.floor(Number(ui.batchSize.value) || 20)
    )
  );
  const rounds = Math.max(1, Math.floor(Number(ui.roundCount.value)||10));
  const plan = PLAN.buildPlan({mode, total, batchSize, rounds});
  const speed = speedConfig();
  return {mode, total, batchSize, rounds, cooldownMs, plan, speed};
};


const deleteAllConfig = () => {
  const batchSize = Math.max(
    1,
    Math.min(
      PLAN.MAX_SELECTION,
      Math.floor(Number(ui.deleteAllBatchSize.value) || 100)
    )
  );
  const cooldownMs = PLAN.sanitizeCooldownMs(
    Number(ui.deleteAllCooldownSeconds.value) * 1000
  );
  return {
    batchSize,
    cooldownMs,
    speed: speedConfig(),
    estimatedTotal: currentCount()
  };
};

const updateDeleteAllEstimate = () => {
  const config = deleteAllConfig();
  const count = config.estimatedTotal;

  if (count <= 0) {
    ui.deleteAllPlan.textContent =
      `${config.batchSize}개씩 · ${Math.round(config.cooldownMs / 1000)}초 휴식`;
    ui.deleteAllTime.textContent =
      `전체 개수 확인 후 예상 시간을 표시합니다. 처리 속도: ${config.speed.label}`;
    syncPresetButtons();
    return;
  }

  const plan = PLAN.buildPlan({
    mode: 'custom',
    total: count,
    batchSize: config.batchSize,
    rounds: 1
  });
  const estimate = PLAN.estimate({
    plan,
    cooldownMs: config.cooldownMs,
    speed: config.speed
  });

  ui.deleteAllPlan.textContent =
    `예상 ${plan.length.toLocaleString()}회 · ${count.toLocaleString()}개`;
  ui.deleteAllTime.textContent =
    `약 ${PLAN.formatDuration(estimate.lowMs)}~${PLAN.formatDuration(estimate.highMs)} · ${config.speed.label} 속도`;
  syncPresetButtons();
};

const updatePlanner = () => {
  const config = planConfig();
  ui.customFields.classList.toggle('hidden', config.mode !== 'custom');
  ui.roundFields.classList.toggle('hidden', config.mode !== 'rounds');
  ui.cooldownFields.classList.remove('hidden');
  ui.allWarning.classList.toggle('hidden', config.mode !== 'all');
  ui.customSpeedFields.classList.toggle('hidden', config.speed.id !== 'custom');

  const speedDescriptions = {
    safe: '선택과 스크롤 사이에 충분히 기다립니다. 화면 반응이 느린 PC에 적합합니다.',
    balanced: '체크 표시가 확인되는 즉시 넘어가며, 기존보다 약 2배 빠릅니다.',
    fast: '최소 대기로 처리합니다. 같은 게시물을 두 번 누르지 않고, 선택 확인이 늦으면 잠깐 더 관찰합니다.',
    custom: `게시물 사이 ${config.speed.clickDelayMs}ms · 스크롤 후 ${config.speed.scrollWaitMs}ms 대기`
  };
  ui.speedDescription.textContent = speedDescriptions[config.speed.id];

  ui.planDescription.textContent = PLAN.describe(config);
  ui.confirmationCount.textContent = `${config.plan.length.toLocaleString()}회`;
  const estimate = PLAN.estimate({
    plan: config.plan,
    cooldownMs: config.cooldownMs,
    speed: config.speed
  });
  ui.estimatedTime.textContent = `약 ${PLAN.formatDuration(estimate.lowMs)}~${PLAN.formatDuration(estimate.highMs)}`;
  updateDeleteCountedButton();
  updateDeleteAllEstimate();
  syncPresetButtons();
};

const formatCheckedTime = (iso) => {
  if (!iso) return '';
  try { return new Intl.DateTimeFormat('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'}).format(new Date(iso)); }
  catch { return ''; }
};

const renderCountResult = (result) => {
  lastCountResult = result || null;
  if (!result) {
    ui.likedCountResult.textContent = '아직 확인하지 않음'; ui.likedCountTime.textContent = '';
  } else {
    const count=Number(result.count)||0;
    ui.likedCountResult.textContent = result.exact ? `총 ${count.toLocaleString()}개` : `최소 ${count.toLocaleString()}개`;
    ui.likedCountTime.textContent = `${formatCheckedTime(result.checkedAt)} 기준`;
    if (!targetTouched && count > 0) ui.cleanupTotal.value = String(count);
  }
  updatePlanner();
};

const updateDeleteCountedButton = () => {
  const count=currentCount();
  const activeNonCount=currentJob && ['running','paused'].includes(currentJob.status) && currentJob.mode !== 'count';
  ui.deleteCounted.disabled = count <= 0 || activeNonCount;
  const label = ui.deleteCounted.querySelector('.buttonLabel');
  const text = count > 0
    ? `현재 설정으로 확인된 ${count.toLocaleString()}개 정리`
    : '현재 설정으로 확인된 게시물 정리';
  if (label) label.textContent = text;
  else ui.deleteCounted.textContent = text;
};

const statusLabel = (status, phase) => {
  if (status==='running' && phase?.startsWith('count')) return phase==='count_restoring' ? '위치 복원 중' : '개수 확인 중';
  if (status==='running' && phase==='list_ready') return '새 목록 준비 완료';
  if (status==='running' && phase==='waiting_reload') return 'Instagram 로딩 대기';
  if (status==='running' && phase==='checking_empty') return '남은 게시물 확인';
  if (status==='running' && phase==='cooling') return '작업 사이 휴식';
  return ({running:'진행 중',paused:'일시정지',completed:'완료',stopped:'중단',blocked:'활동 제한',error:'오류'})[status] || '대기 중';
};

const renderJob = (job) => {
  currentJob=job||null;
  const countMode=job?.mode==='count';
  const deleteAllMode=job?.mode==='delete_all';
  const active=['running','paused'].includes(job?.status);
  document.body.dataset.jobActive = String(active);
  document.body.dataset.jobStatus = job?.status || 'idle';
  const selected=Number(job?.selected)||0;
  const success=countMode ? (Number(job?.counted)||selected) : (Number(job?.totalSuccess ?? job?.success)||0);
  const total=deleteAllMode
    ? (Number(job?.estimatedTotal)||0)
    : (Number(job?.deleteLimit)||Number(job?.planTotal)||Number(job?.target)||0);
  const currentTarget=countMode ? 0 : Number(job?.target)||0;
  const maxBatches=Number(job?.maxBatches)||0;
  const batchIndex=Number(job?.batchIndex)||0;

  ui.jobStatus.textContent=statusLabel(job?.status,job?.phase);
  ui.batchCount.textContent=countMode
    ? '개수 확인'
    : (
        deleteAllMode
          ? `${batchIndex.toLocaleString()}/끝까지`
          : (job ? `${Math.max(1,batchIndex)}/${maxBatches||1}` : '-')
      );
  ui.targetCount.textContent=countMode ? '-' : currentTarget.toLocaleString();
  ui.selectedCount.textContent=(countMode?success:selected).toLocaleString();
  ui.successCount.textContent=success.toLocaleString();

  if ((countMode || deleteAllMode) && job?.status==='running' && !total) {
    ui.progress.removeAttribute('value');
  } else if (countMode) {
    ui.progress.value=100;
  } else if (deleteAllMode && total) {
    ui.progress.value=Math.min(
      100,
      Math.round(((success+selected)/total)*100)
    );
  } else {
    ui.progress.value=total
      ? Math.min(100,Math.round(((success+selected)/total)*100))
      : 0;
  }

  const deleteActive = active && !countMode;
  ui.startCount.disabled = active;
  [ui.startPlannedDelete,ui.cleanupTotal,ui.batchSize,ui.roundCount,ui.cooldownSeconds,ui.useCountResult,ui.autoScroll,ui.clickDelayMs,ui.scrollWaitMs,
    ui.startDeleteAll,ui.deleteAllBatchSize,ui.deleteAllCooldownSeconds]
    .forEach((element)=>{ if(element) element.disabled=deleteActive; });
  ui.strategyInputs.forEach((input)=>{input.disabled=deleteActive;});
  ui.speedInputs.forEach((input)=>{input.disabled=deleteActive;});
  ui.presetButtons.forEach((button)=>{button.disabled=deleteActive;});
  ui.deleteAllBatchPresets.forEach((button)=>{button.disabled=deleteActive;});
  ui.deleteAllCooldownPresets.forEach((button)=>{button.disabled=deleteActive;});
  ui.pause.disabled=!active;
  const pauseLabel=ui.pause.querySelector('.buttonLabel');
  if(pauseLabel) pauseLabel.textContent=job?.status==='paused'?'재개':'일시정지';
  else ui.pause.textContent=job?.status==='paused'?'재개':'일시정지';
  ui.stop.disabled=!active;
  if (job?.message) setMessage(job.message,['error','blocked'].includes(job.status));
  updateDeleteCountedButton();
};

const saveSettings = async () => {
  const config=planConfig();
  await chrome.storage.local.set({[SETTINGS_KEY]:{
    mode:config.mode,total:config.total,batchSize:config.batchSize,rounds:config.rounds,
    cooldownSeconds:Math.round(config.cooldownMs/1000),autoScroll:ui.autoScroll.checked,
    speedMode:config.speed.id,clickDelayMs:config.speed.clickDelayMs,scrollWaitMs:config.speed.scrollWaitMs,
    deleteAllBatchSize:deleteAllConfig().batchSize,
    deleteAllCooldownSeconds:Math.round(deleteAllConfig().cooldownMs/1000)
  }});
};

const refreshPage = async () => {
  const tab=await getActiveTab();
  if(!tab?.url?.startsWith('https://www.instagram.com/')) {
    document.body.dataset.pageReady='false';
    ui.pageStatus.textContent='Instagram 필요';ui.selectStatus.textContent='-';ui.cardStatus.textContent='-';return;
  }
  const onLikesPage=tab.url.includes('/your_activity/interactions/likes');
  document.body.dataset.pageReady=String(onLikesPage);
  ui.pageStatus.textContent=onLikesPage?'좋아요 화면':'다른 화면';
  try {
    const check=await chrome.tabs.sendMessage(tab.id,{type:'CHECK_NATIVE_PAGE'});
    ui.selectStatus.textContent=check?.selectButtonFound||check?.selectionMode?'확인':'미확인';
    ui.cardStatus.textContent=`${Number(check?.visibleCards)||0}개`;
  } catch {ui.selectStatus.textContent='새로고침 필요';ui.cardStatus.textContent='-';}
};

const validateInstagramTab = async () => {
  const tab=await getActiveTab();
  if(!tab?.id||!tab.url?.startsWith('https://www.instagram.com/')) throw new Error('Instagram 좋아요 목록 탭을 먼저 열어주세요.');
  if(!tab.url.includes('/your_activity/interactions/likes')) throw new Error('현재 탭이 Instagram 좋아요 목록 화면이 아닙니다.');
  return tab;
};

const startCountJob = async () => {
  try {
    const tab=await validateInstagramTab(); setMessage('좋아요 목록을 끝까지 스크롤하며 전체 개수를 확인합니다.');
    const speed=speedConfig();
    const response=await chrome.runtime.sendMessage({
      type:'START_COUNT_JOB',
      tabId:tab.id,
      speedMode:speed.id,
      clickDelayMs:speed.clickDelayMs,
      scrollWaitMs:speed.scrollWaitMs
    });
    if(!response?.ok) throw new Error(response?.message||'개수 확인을 시작하지 못했습니다.'); renderJob(response.job);
  } catch(error){setMessage(error.message,true);}
};

const confirmPlan = (config, countIsLive=false) => {
  const estimate=PLAN.estimate({
    plan:config.plan,
    cooldownMs:config.cooldownMs,
    speed:config.speed
  });
  const warning=config.mode==='all'
    ? `\n\nInstagram은 회당 최대 ${PLAN.MAX_SELECTION}개까지만 선택할 수 있어 자동 분할합니다.`
    : '';
  return window.confirm(
    `${config.total.toLocaleString()}개를 정리합니다.\n\n`+
    `방식: ${PLAN.describe(config)}\n`+
    `작업 사이 휴식: ${Math.round(config.cooldownMs/1000)}초\n`+
    `처리 속도: ${config.speed.label}\n`+
    `회당 최대 선택: ${PLAN.MAX_SELECTION}개\n`+
    `예상 시간: ${PLAN.formatDuration(estimate.lowMs)}~${PLAN.formatDuration(estimate.highMs)}\n`+
    (countIsLive?'현재 개수 확인을 멈추고 정리 작업으로 전환합니다.':'')+warning+'\n\n계속할까요?'
  );
};

const startDelete = async (totalOverride=null) => {
  try {
    const tab=await validateInstagramTab();
    const config=planConfig(totalOverride);
    const counting=currentJob?.mode==='count'&&['running','paused'].includes(currentJob.status);
    if(!confirmPlan(config,counting)) return;
    await saveSettings(); setMessage(`${PLAN.describe(config)} 방식으로 정리를 준비합니다.`);
    const response=await chrome.runtime.sendMessage({
      type:'START_DELETE_PLAN_JOB',tabId:tab.id,total:config.total,mode:config.mode,batchSize:config.batchSize,
      rounds:config.rounds,cooldownMs:config.cooldownMs,autoScroll:ui.autoScroll.checked,
      speedMode:config.speed.id,clickDelayMs:config.speed.clickDelayMs,scrollWaitMs:config.speed.scrollWaitMs
    });
    if(!response?.ok) throw new Error(response?.message||'정리 작업을 시작하지 못했습니다.'); renderJob(response.job);
  } catch(error){setMessage(error.message,true);}
};


const startDeleteAllJob = async () => {
  try {
    const tab = await validateInstagramTab();
    const config = deleteAllConfig();
    const estimateText = config.estimatedTotal > 0
      ? `\n현재 확인 결과: 약 ${config.estimatedTotal.toLocaleString()}개`
      : '';

    const accepted = window.confirm(
      `좋아요 게시물이 없어질 때까지 전체 삭제합니다.\n\n` +
      `한 번에: ${config.batchSize}개\n` +
      `작업 사이 휴식: ${Math.round(config.cooldownMs / 1000)}초\n` +
      `체크·스크롤 속도: ${config.speed.label}` +
      estimateText +
      `\n\n빈 목록을 여러 번 확인한 뒤 완료 처리합니다. 계속할까요?`
    );
    if (!accepted) return;

    await saveSettings();
    setMessage(
      `${config.batchSize}개씩 반복하며 좋아요가 없어질 때까지 정리합니다.`
    );

    const response = await chrome.runtime.sendMessage({
      type: 'START_DELETE_ALL_JOB',
      tabId: tab.id,
      batchSize: config.batchSize,
      cooldownMs: config.cooldownMs,
      autoScroll: ui.autoScroll.checked,
      speedMode: config.speed.id,
      clickDelayMs: config.speed.clickDelayMs,
      scrollWaitMs: config.speed.scrollWaitMs,
      estimatedTotal: config.estimatedTotal
    });

    if (!response?.ok) {
      throw new Error(
        response?.message || '전체 삭제를 시작하지 못했습니다.'
      );
    }
    renderJob(response.job);
  } catch (error) {
    setMessage(error.message, true);
  }
};

ui.openLikes.addEventListener('click',async()=>{await chrome.runtime.sendMessage({type:'OPEN_LIKES_PAGE'});window.close();});
ui.startCount.addEventListener('click',startCountJob);
ui.deleteCounted.addEventListener('click',()=>startDelete(currentCount()));
ui.startPlannedDelete.addEventListener('click',()=>startDelete());
ui.startDeleteAll.addEventListener('click',startDeleteAllJob);
ui.useCountResult.addEventListener('click',()=>{const count=currentCount();if(count>0){ui.cleanupTotal.value=String(count);targetTouched=true;updatePlanner();}else setMessage('먼저 전체 좋아요 개수를 확인해주세요.',true);});
ui.strategyInputs.forEach((input)=>input.addEventListener('change',()=>{updatePlanner();saveSettings();}));
ui.speedInputs.forEach((input)=>input.addEventListener('change',()=>{updatePlanner();saveSettings();}));
[ui.cleanupTotal,ui.batchSize,ui.roundCount,ui.cooldownSeconds,ui.clickDelayMs,ui.scrollWaitMs].forEach((input)=>input.addEventListener('input',()=>{if(input===ui.cleanupTotal)targetTouched=true;updatePlanner();}));
[ui.cleanupTotal,ui.batchSize,ui.roundCount,ui.cooldownSeconds,ui.autoScroll,ui.clickDelayMs,ui.scrollWaitMs].forEach((input)=>input.addEventListener('change',saveSettings));
ui.presetButtons.forEach((button)=>button.addEventListener('click',()=>{ui.cooldownSeconds.value=button.dataset.seconds;updatePlanner();saveSettings();}));
ui.deleteAllBatchPresets.forEach((button)=>button.addEventListener('click',()=>{
  ui.deleteAllBatchSize.value=button.dataset.value;
  updateDeleteAllEstimate();
  saveSettings();
}));
ui.deleteAllCooldownPresets.forEach((button)=>button.addEventListener('click',()=>{
  ui.deleteAllCooldownSeconds.value=button.dataset.value;
  updateDeleteAllEstimate();
  saveSettings();
}));
[ui.deleteAllBatchSize,ui.deleteAllCooldownSeconds].forEach((input)=>{
  input.addEventListener('input',updateDeleteAllEstimate);
  input.addEventListener('change',saveSettings);
});
ui.pause.addEventListener('click',async()=>{const type=currentJob?.status==='paused'?'RESUME_NATIVE_JOB':'PAUSE_NATIVE_JOB';const response=await chrome.runtime.sendMessage({type});response?.ok?renderJob(response.job):setMessage(response?.message||'상태를 변경하지 못했습니다.',true);});
ui.stop.addEventListener('click',async()=>{const response=await chrome.runtime.sendMessage({type:'STOP_NATIVE_JOB'});response?.ok?renderJob(response.job):setMessage(response?.message||'작업을 중단하지 못했습니다.',true);});
ui.clear.addEventListener('click',async()=>{await chrome.runtime.sendMessage({type:'CLEAR_NATIVE_JOB'});renderJob(null);setMessage('완료 기록을 지웠습니다.');});

chrome.runtime.onMessage.addListener((message)=>{if(message?.type==='NATIVE_JOB_UPDATED')renderJob(message.job);if(message?.type==='COUNT_RESULT_UPDATED')renderCountResult(message.result);});
chrome.storage.onChanged.addListener((changes,areaName)=>{if(areaName!=='local')return;if(changes[JOB_KEY])renderJob(changes[JOB_KEY].newValue||null);if(changes[COUNT_RESULT_KEY])renderCountResult(changes[COUNT_RESULT_KEY].newValue||null);});

(async()=>{
  const stored=await chrome.storage.local.get(SETTINGS_KEY); const settings=stored[SETTINGS_KEY]||{};
  ui.cleanupTotal.value=String(settings.total||20); ui.batchSize.value=String(settings.batchSize||20); ui.roundCount.value=String(settings.rounds||10);
  ui.cooldownSeconds.value=String(settings.cooldownSeconds||60); ui.autoScroll.checked=settings.autoScroll!==false;
  ui.clickDelayMs.value=String(settings.clickDelayMs ?? 65);
  ui.scrollWaitMs.value=String(settings.scrollWaitMs ?? 430);
  ui.deleteAllBatchSize.value=String(settings.deleteAllBatchSize ?? 100);
  ui.deleteAllCooldownSeconds.value=String(settings.deleteAllCooldownSeconds ?? 60);
  const modeInput=ui.strategyInputs.find((input)=>input.value===(settings.mode||'custom')); if(modeInput)modeInput.checked=true;
  const speedInput=ui.speedInputs.find((input)=>input.value===(settings.speedMode||'balanced')); if(speedInput)speedInput.checked=true;
  syncPresetButtons();
  updatePlanner(); await refreshPage();
  const [jobResponse,countResponse]=await Promise.all([
    chrome.runtime.sendMessage({type:'GET_NATIVE_JOB'}),chrome.runtime.sendMessage({type:'GET_COUNT_RESULT'})
  ]);
  renderJob(jobResponse?.job||null); renderCountResult(countResponse?.result||null);
})();

(() => {
  const CORE = globalThis.__INSTAGRAM_LIKE_CLEANER_CORE__;
  if (!CORE) return;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));


  const SPEED_PROFILES = {
    safe: {
      id: 'safe',
      clickDelayMs: 180,
      scrollSettleMs: 260,
      scrollWaitMs: 900,
      countScrollWaitMs: 760,
      bottomWaitMs: 1200,
      verificationTimeoutMs: 1200,
      verificationPollMs: 80,
      navigationBackWaitMs: 900
    },
    balanced: {
      id: 'balanced',
      clickDelayMs: 65,
      scrollSettleMs: 90,
      scrollWaitMs: 430,
      countScrollWaitMs: 380,
      bottomWaitMs: 720,
      verificationTimeoutMs: 700,
      verificationPollMs: 50,
      navigationBackWaitMs: 550
    },
    fast: {
      id: 'fast',
      clickDelayMs: 15,
      scrollSettleMs: 35,
      scrollWaitMs: 240,
      countScrollWaitMs: 210,
      bottomWaitMs: 520,
      verificationTimeoutMs: 480,
      verificationPollMs: 35,
      navigationBackWaitMs: 420
    }
  };

  const normalizeTiming = (options = {}) => {
    const mode = ['safe', 'balanced', 'fast', 'custom'].includes(options.speedMode)
      ? options.speedMode
      : 'balanced';

    if (mode !== 'custom') {
      return {...SPEED_PROFILES[mode]};
    }

    const clickDelayMs = Math.max(
      0,
      Math.min(Number(options.clickDelayMs) || 65, 2000)
    );
    const scrollWaitMs = Math.max(
      120,
      Math.min(Number(options.scrollWaitMs) || 430, 5000)
    );

    return {
      id: 'custom',
      clickDelayMs,
      scrollSettleMs: Math.max(25, Math.min(180, clickDelayMs * 0.45 + 25)),
      scrollWaitMs,
      countScrollWaitMs: scrollWaitMs,
      bottomWaitMs: Math.max(450, scrollWaitMs * 1.55),
      verificationTimeoutMs: Math.max(380, Math.min(2500, clickDelayMs + 420)),
      verificationPollMs: 45,
      navigationBackWaitMs: Math.max(420, Math.min(1200, scrollWaitMs))
    };
  };

  const activeTiming = () =>
    state.timing ||
    countState.timing ||
    SPEED_PROFILES.balanced;

  const state = {
    running: false,
    paused: false,
    stopped: false,
    target: 0,
    selected: 0,
    tentativeSelected: 0,
    clickedKeys: new Set(),
    originalPath: '',
    continuous: false,
    batchIndex: 0,
    maxBatches: 0,
    totalSuccess: 0,
    cooldownMs: 0,
    deleteLimit: 0,
    batchPlan: [],
    strategyMode: 'custom',
    timing: null,
    lastUnlikeSubmittedAt: 0,
    lastDeletedGridSnapshot: null
  };

  const countState = {
    running: false,
    paused: false,
    stopped: false,
    counted: 0,
    complete: false,
    deleteRequested: false,
    deleteOptions: null,
    timing: null
  };

  const isLikesPage = () =>
    location.pathname.includes('/your_activity/interactions/likes');

  const selectionLimitVisible = () => {
    const text = CORE.normalize(
      document.body?.innerText ||
      document.body?.textContent ||
      ''
    );

    return (
      text.includes('일부 콘텐츠를 선택 취소하세요') ||
      text.includes('deselect some content') ||
      text.includes('선택한 콘텐츠 중 일부를 취소')
    );
  };

  const waitFor = async (
    predicate,
    timeoutMs = 8000,
    intervalMs = 200
  ) => {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const result = predicate();
      if (result) return result;
      await sleep(intervalMs);
    }
    return null;
  };

  const waitWhilePaused = async () => {
    while (state.paused && !state.stopped) {
      await sleep(200);
    }
  };

  const report = (phase, message, extra = {}) => {
    chrome.runtime.sendMessage({
      type: 'NATIVE_JOB_PROGRESS',
      progress: {
        phase,
        message,
        target: state.target,
        selected: state.selected || state.tentativeSelected,
        continuous: state.continuous,
        batchIndex: state.batchIndex,
        maxBatches: state.maxBatches,
        totalSuccess: state.totalSuccess,
        cooldownMs: state.cooldownMs,
        strategyMode: state.strategyMode,
        ...extra
      }
    }).catch(() => {});
  };

  const dispatchRealisticClick = async (element) => {
    if (!element?.isConnected) return false;

    element.scrollIntoView({
      block: 'center',
      inline: 'center',
      behavior: 'smooth'
    });
    await sleep(activeTiming().scrollSettleMs);

    // Critical: calculate the point only after scrollIntoView has finished.
    const freshRect = CORE.rect(element);
    if (!freshRect || freshRect.width < 8 || freshRect.height < 8) {
      return false;
    }

    const x = freshRect.left + freshRect.width / 2;
    const y = freshRect.top + freshRect.height / 2;

    if (
      x <= 0 ||
      y <= 0 ||
      x >= window.innerWidth ||
      y >= window.innerHeight
    ) {
      return false;
    }

    const hit = document.elementFromPoint(x, y);
    const hitBelongsToCard = Boolean(
      hit &&
      (
        hit === element ||
        element.contains?.(hit) ||
        hit.contains?.(element)
      )
    );

    // Never click whatever happens to be under an old coordinate.
    const rawTarget = hitBelongsToCard ? hit : element;
    const target = CORE.clickable(rawTarget) || rawTarget;

    const anchor = target.closest?.('a[href]');
    if (
      anchor &&
      !CORE.isPostHref(anchor.getAttribute('href'))
    ) {
      return false;
    }

    const eventOptions = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      button: 0,
      buttons: 1,
      pointerId: 1,
      pointerType: 'mouse',
      isPrimary: true
    };

    try {
      target.dispatchEvent(new PointerEvent('pointerover', eventOptions));
      target.dispatchEvent(new PointerEvent('pointerenter', eventOptions));
      target.dispatchEvent(new MouseEvent('mouseover', eventOptions));
      target.dispatchEvent(new PointerEvent('pointerdown', eventOptions));
      target.dispatchEvent(new MouseEvent('mousedown', eventOptions));
      target.dispatchEvent(new PointerEvent('pointerup', {
        ...eventOptions,
        buttons: 0
      }));
      target.dispatchEvent(new MouseEvent('mouseup', {
        ...eventOptions,
        buttons: 0
      }));
      target.dispatchEvent(new MouseEvent('click', {
        ...eventOptions,
        buttons: 0
      }));
      return true;
    } catch {
      try {
        target.click();
        return true;
      } catch {
        return false;
      }
    }
  };

  const findScrollable = () => {
    const root =
      document.querySelector('main') ||
      document.querySelector('[role="main"]');

    const candidates = [
      root,
      document.scrollingElement,
      document.documentElement,
      document.body,
      ...document.querySelectorAll('main div, [role="main"] div')
    ].filter(Boolean)
      .filter((element) => {
        const rect = element.getBoundingClientRect?.();
        if (!rect || rect.width < 280 || rect.height < 280) return false;
        return element.scrollHeight > element.clientHeight + 180;
      })
      .sort((a, b) => {
        const aInside = root && (a === root || root.contains(a)) ? 1 : 0;
        const bInside = root && (b === root || root.contains(b)) ? 1 : 0;
        if (aInside !== bInside) return bInside - aInside;
        return (
          (b.scrollHeight - b.clientHeight) -
          (a.scrollHeight - a.clientHeight)
        );
      });

    return candidates[0] || document.scrollingElement;
  };

  const scrollForMore = async () => {
    const scroller = findScrollable();
    const amount = Math.max(
      window.innerHeight * 0.68,
      scroller?.clientHeight ? scroller.clientHeight * 0.72 : 0,
      480
    );

    if (
      scroller === document.scrollingElement ||
      scroller === document.documentElement ||
      scroller === document.body
    ) {
      window.scrollBy({top: amount, behavior: 'smooth'});
    } else {
      scroller.scrollBy({top: amount, behavior: 'smooth'});
    }

    await sleep(activeTiming().scrollWaitMs);
  };

  const ensureSelectionMode = async () => {
    if (CORE.selectionModeActive(document)) return true;

    const selectButton = await waitFor(
      () => CORE.findSelectButton(document),
      6500,
      250
    );

    if (!selectButton) {
      return {
        ok: false,
        status: 'select_button_not_found',
        message: 'Instagram의 “선택” 버튼을 찾지 못했습니다.'
      };
    }

    report('opening_selection', 'Instagram의 “선택” 버튼을 누르는 중입니다.');
    const clicked = await dispatchRealisticClick(selectButton);
    if (!clicked) {
      return {
        ok: false,
        status: 'select_button_click_failed',
        message: 'Instagram의 “선택” 버튼을 누르지 못했습니다.'
      };
    }

    const modeActive = await waitFor(
      () => CORE.selectionModeActive(document),
      6000,
      200
    );

    if (!modeActive) {
      return {
        ok: false,
        status: 'selection_mode_not_confirmed',
        message: '“선택” 버튼은 눌렀지만 선택 화면으로 바뀌지 않았습니다.'
      };
    }

    return {ok: true};
  };

  const cardStateSignature = (card) => {
    const element = card.element;
    const selected =
      element.matches?.(
        '[aria-selected="true"], [aria-checked="true"], [data-state="checked"]'
      ) ||
      Boolean(
        element.querySelector?.(
          '[aria-selected="true"], [aria-checked="true"], [data-state="checked"], input:checked, [aria-label="선택됨"], [aria-label*="selected" i]'
        )
      );

    return {selected: Boolean(selected)};
  };

  const clickOneCard = async (card) => {
    const beforePath = location.pathname;
    const beforeNative = CORE.selectedCount(document);
    const beforeSignature = cardStateSignature(card);
    const timing = activeTiming();

    const clicked = await dispatchRealisticClick(card.element);
    if (!clicked) {
      return {ok:false,verified:false};
    }

    const readSelection = () => {
      if (location.pathname !== beforePath) {
        return {navigationDetected:true};
      }

      const afterNative = CORE.selectedCount(document);
      const afterSignature = cardStateSignature(card);
      const verified =
        afterNative > beforeNative ||
        (!beforeSignature.selected && afterSignature.selected);

      return verified
        ? {
            verified:true,
            nativeCount:afterNative
          }
        : null;
    };

    let result = await waitFor(
      readSelection,
      timing.verificationTimeoutMs,
      timing.verificationPollMs
    );

    if (result?.navigationDetected || location.pathname !== beforePath) {
      try {
        history.back();
        await sleep(timing.navigationBackWaitMs);
      } catch {}
      return {
        ok:false,
        verified:false,
        navigationDetected:true
      };
    }

    if (!result?.verified) {
      // Never click the same card twice. Instagram can apply the first
      // click late, and a second click would immediately deselect it.
      const stabilizationMs =
        timing.id === 'fast'
          ? 260
          : timing.id === 'balanced'
            ? 340
            : 460;

      result = await waitFor(
        readSelection,
        stabilizationMs,
        timing.verificationPollMs
      );
    }

    if (result?.navigationDetected || location.pathname !== beforePath) {
      try {
        history.back();
        await sleep(timing.navigationBackWaitMs);
      } catch {}
      return {
        ok:false,
        verified:false,
        navigationDetected:true
      };
    }

    if (result?.verified) {
      return {
        ok:true,
        verified:true,
        nativeCount:result.nativeCount
      };
    }

    return {
      ok:false,
      verified:false,
      uncertain:true,
      nativeCount:CORE.selectedCount(document)
    };
  };

  const selectRequestedCards = async (autoScroll, allowPartial = false) => {
    let emptyPasses = 0;
    let navigationErrors = 0;

    const maxPasses = Math.min(2500, Math.max(24, Math.ceil(state.target / 3) + 60));

    for (
      let pass = 0;
      pass < maxPasses &&
      !state.stopped &&
      (state.selected || state.tentativeSelected) < state.target;
      pass += 1
    ) {
      await waitWhilePaused();
      if (state.stopped) break;

      const restriction = CORE.detectRestriction(document);
      if (restriction) {
        return {
          ok: false,
          status: 'blocked',
          message: 'Instagram 활동 제한 안내가 감지되었습니다.'
        };
      }

      if (selectionLimitVisible()) {
        return {
          ok: false,
          status: 'selection_limit',
          message:
            'Instagram의 회당 선택 한도 100개에 도달했습니다. 선택 화면을 취소한 뒤 새 버전으로 다시 실행해주세요.'
        };
      }

      const cards = CORE.findGridCards(document);
      const available = cards.filter((card) =>
        card.key && !state.clickedKeys.has(card.key)
      );

      let clickedThisPass = 0;

      for (const card of available) {
        await waitWhilePaused();
        if (state.stopped) break;
        if ((state.selected || state.tentativeSelected) >= state.target) break;

        state.clickedKeys.add(card.key);
        const result = await clickOneCard(card);

        if (result.navigationDetected) {
          navigationErrors += 1;
          return {
            ok: false,
            status: 'selection_mode_lost',
            message: '게시물이 선택되지 않고 다른 페이지가 열려 작업을 즉시 중단했습니다.'
          };
        }

        if (!result.ok || !result.verified) continue;
        clickedThisPass += 1;

        if (result.nativeCount > 0) {
          state.selected = Math.max(
            state.selected,
            result.nativeCount
          );
          state.tentativeSelected = state.selected;
        } else {
          state.tentativeSelected += 1;
        }

        const shown = Math.min(
          state.target,
          Math.max(state.selected, state.tentativeSelected)
        );

        report(
          'selecting',
          `${shown}/${state.target}개 게시물을 선택하는 중입니다.`,
          {selected: shown}
        );

        if (activeTiming().clickDelayMs > 0) {
          await sleep(activeTiming().clickDelayMs);
        }
      }

      const currentCount = Math.max(
        state.selected,
        state.tentativeSelected
      );
      if (currentCount >= state.target) break;

      emptyPasses = clickedThisPass === 0
        ? emptyPasses + 1
        : 0;

      if (!autoScroll || emptyPasses >= 4) break;

      report(
        'scrolling',
        `게시물이 부족해 아래로 스크롤하는 중입니다. (${currentCount}/${state.target})`,
        {selected: currentCount}
      );
      await scrollForMore();
    }

    const finalNative = CORE.selectedCount(document);
    if (finalNative > 0) {
      state.selected = finalNative;
      state.tentativeSelected = finalNative;
    }

    const finalCount = Math.min(
      state.target,
      Math.max(state.selected, state.tentativeSelected)
    );

    if (finalCount <= 0) {
      return {
        ok: false,
        status: 'no_cards_selected',
        message: '게시물 카드를 찾았지만 선택 상태로 만들지 못했습니다.'
      };
    }

    if (finalCount < state.target) {
      if (allowPartial && finalCount > 0) {
        const requested = state.target;
        state.target = finalCount;
        return {
          ok: true,
          selected: finalCount,
          partial: true,
          requested
        };
      }

      return {
        ok: false,
        status: 'not_enough_cards',
        selected: finalCount,
        message: `${state.target}개 중 ${finalCount}개만 선택되었습니다. 좋아요 취소는 실행하지 않았습니다.`
      };
    }

    return {ok: true, selected: finalCount, partial: false};
  };

  const visibleDialog = () => {
    return [
      ...document.querySelectorAll(
        '[role="dialog"], [aria-modal="true"]'
      )
    ].find((element) => CORE.visible(element)) || null;
  };

  const gridSnapshot = () => {
    const cards = CORE.findGridCards(document);
    return {
      count: cards.length,
      keys: cards
        .map((card) => card.key)
        .filter(Boolean)
        .slice(0, 30)
    };
  };

  const gridChanged = (before, after) => {
    if (!before || !after) return false;
    if (before.count !== after.count) return true;

    const beforeSet = new Set(before.keys);
    const common = after.keys.filter((key) =>
      beforeSet.has(key)
    ).length;
    const baseline = Math.max(
      1,
      Math.min(before.keys.length, after.keys.length)
    );

    return common / baseline < 0.72;
  };

  const successNoticeVisible = () => {
    const text = CORE.normalize(
      document.body?.innerText ||
      document.body?.textContent ||
      ''
    );

    const phrases = [
      '좋아요 취소됨',
      '좋아요를 취소했습니다',
      '좋아요가 취소되었습니다',
      'likes removed',
      'like removed',
      'unliked',
      'removed your likes'
    ];

    return phrases.some((phrase) =>
      text.includes(CORE.normalize(phrase))
    );
  };

  const leaveSelectionModeIfNeeded = async () => {
    const selectReturned = CORE.findSelectButton(document);
    if (selectReturned) return true;

    const selectedCount = CORE.selectedCount(document);
    const bulkButton = CORE.findBulkUnlikeButton(document);
    const selectionStillActive =
      selectedCount > 0 ||
      Boolean(bulkButton) ||
      CORE.selectionModeActive(document);

    if (!selectionStillActive) return true;

    const cancelButton = CORE.findCancelSelectionButton(document);
    if (!cancelButton) {
      // Instagram may keep the selection toolbar for a moment.
      await sleep(1200);
      return Boolean(CORE.findSelectButton(document)) ||
        CORE.selectedCount(document) === 0;
    }

    await dispatchRealisticClick(cancelButton);
    await waitFor(
      () =>
        CORE.findSelectButton(document) ||
        CORE.selectedCount(document) === 0,
      5000,
      200
    );

    return true;
  };

  const confirmBulkUnlike = async () => {
    if (state.stopped) {
      return {
        ok: false,
        status: 'stopped',
        message: '중단 요청으로 좋아요 취소를 실행하지 않았습니다.'
      };
    }

    report(
      'finding_unlike',
      `${state.target}개 선택 완료. “좋아요 취소” 버튼을 찾는 중입니다.`,
      {selected: state.target}
    );

    const beforeGrid = gridSnapshot();
    const beforeSelected = Math.max(
      state.target,
      CORE.selectedCount(document)
    );

    const bulkButton = await waitFor(
      () => CORE.findBulkUnlikeButton(document),
      7000,
      220
    );

    if (!bulkButton) {
      return {
        ok: false,
        status: 'bulk_unlike_not_found',
        message: '게시물은 선택했지만 “좋아요 취소” 버튼을 찾지 못했습니다.'
      };
    }

    if (state.stopped) {
      return {
        ok: false,
        status: 'stopped',
        message: '중단 요청으로 좋아요 취소를 실행하지 않았습니다.'
      };
    }

    const clicked = await dispatchRealisticClick(bulkButton);
    if (!clicked) {
      return {
        ok: false,
        status: 'bulk_unlike_click_failed',
        message: '“좋아요 취소” 버튼을 누르지 못했습니다.'
      };
    }

    state.lastUnlikeSubmittedAt = Date.now();

    report(
      'confirming',
      'Instagram의 최종 확인창을 처리하는 중입니다.',
      {selected: state.target}
    );
    await sleep(450);

    const confirmation = await waitFor(
      () => CORE.findBulkUnlikeButton(
        document,
        {dialogOnly: true}
      ),
      4500,
      180
    );

    let confirmationClicked = false;

    if (confirmation && confirmation !== bulkButton) {
      if (state.stopped) {
        return {
          ok: false,
          status: 'stopped',
          message: '중단 요청으로 최종 확인을 실행하지 않았습니다.'
        };
      }

      const confirmed = await dispatchRealisticClick(confirmation);
      if (!confirmed) {
        return {
          ok: false,
          status: 'confirmation_click_failed',
          message: '최종 확인창의 “좋아요 취소” 버튼을 누르지 못했습니다.'
        };
      }
      confirmationClicked = true;
      state.lastUnlikeSubmittedAt = Date.now();
    } else {
      // Some Instagram layouts perform the action with one button.
      confirmationClicked = true;
    }

    const verificationStarted = Date.now();
    let successSignal = null;

    const finished = await waitFor(() => {
      if (CORE.detectRestriction(document)) {
        return {status: 'blocked'};
      }

      const dialog = visibleDialog();
      const confirmStillVisible = CORE.findBulkUnlikeButton(
        document,
        {dialogOnly: true}
      );
      const dialogClosed = !dialog || !confirmStillVisible;

      const currentSelected = CORE.selectedCount(document);
      const currentGrid = gridSnapshot();
      const selectReturned = Boolean(
        CORE.findSelectButton(document)
      );
      const bulkGone = !CORE.findBulkUnlikeButton(document);
      const notice = successNoticeVisible();
      const changed = gridChanged(beforeGrid, currentGrid);
      const selectionReduced =
        currentSelected < beforeSelected ||
        currentSelected === 0;

      if (dialogClosed && notice) {
        return {
          status: 'success',
          signal: 'success_notice'
        };
      }

      if (dialogClosed && changed) {
        return {
          status: 'success',
          signal: 'grid_changed'
        };
      }

      if (dialogClosed && selectionReduced) {
        return {
          status: 'success',
          signal: 'selection_reset'
        };
      }

      if (dialogClosed && selectReturned) {
        return {
          status: 'success',
          signal: 'select_returned'
        };
      }

      if (dialogClosed && bulkGone) {
        return {
          status: 'success',
          signal: 'bulk_button_gone'
        };
      }

      // Instagram sometimes leaves the selection toolbar mounted even
      // after the request succeeded. A closed confirmation dialog with
      // no restriction for five seconds is sufficient to continue.
      if (
        confirmationClicked &&
        dialogClosed &&
        Date.now() - verificationStarted >= 3000
      ) {
        return {
          status: 'success',
          signal: 'dialog_closed_grace'
        };
      }

      return null;
    }, 9000, 220);

    if (finished?.status === 'blocked') {
      return {
        ok: false,
        status: 'blocked',
        message: '좋아요 취소 중 Instagram 활동 제한이 감지되었습니다.'
      };
    }

    if (finished?.status !== 'success') {
      const dialog = visibleDialog();
      const confirmStillVisible = CORE.findBulkUnlikeButton(
        document,
        {dialogOnly: true}
      );

      // Do not repeat a destructive click. If the confirmation UI has
      // disappeared, treat the submitted action as completed.
      if (
        confirmationClicked &&
        (!dialog || !confirmStillVisible) &&
        !CORE.detectRestriction(document)
      ) {
        successSignal = 'submitted_without_visual_reset';
      } else {
        return {
          ok: false,
          status: 'completion_not_confirmed',
          message:
            '확인창이 계속 열려 있거나 Instagram 오류가 감지되어 다음 배치로 넘어가지 않았습니다.'
        };
      }
    } else {
      successSignal = finished.signal;
    }

    report(
      'resetting',
      '완료된 선택 화면을 정리하고 다음 배치를 준비합니다.',
      {selected: 0}
    );

    await leaveSelectionModeIfNeeded();
    await sleep(
      Math.max(180, Math.min(420, activeTiming().scrollWaitMs))
    );

    state.lastDeletedGridSnapshot = beforeGrid;

    return {
      ok: true,
      status: 'completed',
      success: state.target,
      selected: state.target,
      verificationSignal: successSignal,
      message:
        `${state.target}개 게시물의 좋아요 취소를 완료했습니다.`
    };
  };

  const resetBatchState = (target, batchIndex = 1) => {
    state.target = Math.max(
      1,
      Math.min(Number(target) || 20, 100)
    );
    state.batchIndex = batchIndex;
    state.selected = 0;
    state.tentativeSelected = 0;
    state.clickedKeys = new Set();
    state.originalPath = location.pathname;
  };

  const executeOneBatch = async (options = {}) => {
    resetBatchState(
      options.target,
      options.batchIndex || 1
    );

    report(
      'preparing',
      state.continuous
        ? `${state.batchIndex}번째 배치: ${state.target}개 정리를 준비합니다.`
        : `${state.target}개 자동 취소 작업을 준비하는 중입니다.`,
      {selected: 0}
    );

    const restriction = CORE.detectRestriction(document);
    if (restriction) {
      return {
        ok: false,
        status: 'blocked',
        message: 'Instagram 활동 제한 안내가 감지되었습니다.'
      };
    }

    const selectionMode = await ensureSelectionMode();
    if (!selectionMode.ok) return selectionMode;

    const selected = await selectRequestedCards(
      options.autoScroll !== false,
      options.allowPartial === true
    );
    if (!selected.ok) return selected;

    if (state.stopped) {
      return {
        ok: false,
        status: 'stopped',
        selected: Math.max(
          state.selected,
          state.tentativeSelected
        ),
        message: '사용자가 작업을 중단했습니다.'
      };
    }

    return await confirmBulkUnlike();
  };

  const waitForCooldown = async (cooldownMs) => {
    const totalMs = Math.max(
      5000,
      Number(cooldownMs) || 60000
    );
    const submittedAt =
      Number(state.lastUnlikeSubmittedAt) || Date.now();

    while (!state.stopped) {
      await waitWhilePaused();
      if (state.stopped) return false;

      const elapsedMs = Math.max(
        0,
        Date.now() - submittedAt
      );
      const remainingMs = Math.max(
        0,
        totalMs - elapsedMs
      );

      if (remainingMs <= 0) {
        report(
          'cooling',
          `휴식 완료. 다음 목록을 확인합니다. 누적 ${state.totalSuccess.toLocaleString()}개 완료.`,
          {
            selected:0,
            cooldownRemaining:0
          }
        );
        return true;
      }

      const remainingSeconds = Math.ceil(
        remainingMs / 1000
      );

      report(
        'cooling',
        `다음 작업까지 ${remainingSeconds}초 · Instagram 처리 시간 포함`,
        {
          selected:0,
          cooldownRemaining:remainingSeconds
        }
      );

      await sleep(
        Math.min(1000, remainingMs)
      );
    }

    return false;
  };

  const runNativePlan = async (options = {}) => {
    if (state.running) return {ok:false,status:'busy',message:'이미 좋아요 취소 작업이 진행 중입니다.'};
    if (!isLikesPage()) return {ok:false,status:'wrong_page',message:'Instagram의 내 활동 > 좋아요 화면에서 실행해주세요.'};

    const plan = (Array.isArray(options.plan) ? options.plan : [])
      .map((value) =>
        Math.max(
          1,
          Math.min(
            Math.floor(Number(value) || 0),
            100
          )
        )
      )
      .filter(Boolean)
      .slice(0, 10000);
    if (!plan.length) return {ok:false,status:'empty_plan',message:'실행할 정리 계획이 없습니다.'};

    Object.assign(state, {
      running:true, paused:false, stopped:false, continuous:plan.length>1,
      batchIndex:0, maxBatches:plan.length, totalSuccess:0,
      cooldownMs:Math.max(5000,Math.min(Number(options.cooldownMs)||60000,3600000)),
      deleteLimit:plan.reduce((sum,value)=>sum+value,0), batchPlan:plan,
      strategyMode:options.strategyMode||'custom',
      timing:normalizeTiming(options),
      lastDeletedGridSnapshot:null
    });

    if (options.resetToTop === true) {
      report('resetting','정리를 시작하기 위해 좋아요 목록 맨 위로 이동합니다.',{selected:0});
      await setScrollPosition(findScrollable(),0,'auto');
      await sleep(Math.max(220,state.timing.scrollWaitMs));
    }

    try {
      while (!state.stopped && state.batchIndex < state.batchPlan.length) {
        await waitWhilePaused(); if(state.stopped) break;
        const planIndex=state.batchIndex;
        const currentBatchSize=state.batchPlan[planIndex];
        const result=await executeOneBatch({target:currentBatchSize,batchIndex:planIndex+1,autoScroll:options.autoScroll!==false});
        if(!result.ok){
          const partial=state.totalSuccess?` 누적 ${state.totalSuccess.toLocaleString()}개는 완료했습니다.`:'';
          return {...result,totalSuccess:state.totalSuccess,success:state.totalSuccess,batchIndex:state.batchIndex,message:`${result.message||'정리 작업이 중단되었습니다.'}${partial}`};
        }
        state.batchIndex=planIndex+1;
        state.totalSuccess += Number(result.success)||currentBatchSize;
        report('batch_completed',`${state.batchIndex}/${state.maxBatches} 작업 완료. 누적 ${state.totalSuccess.toLocaleString()}개를 정리했습니다.`,{selected:0,totalSuccess:state.totalSuccess});
        if(state.batchIndex>=state.batchPlan.length) continue;

        const shouldContinue=await waitForCooldown(state.cooldownMs);
        if(!shouldContinue) break;

        const readiness=await probeRemainingLikedPosts({
          previousSnapshot:state.lastDeletedGridSnapshot
        });

        if(!readiness.ok){
          if(readiness.status==='stopped') break;
          return {
            ...readiness,
            totalSuccess:state.totalSuccess,
            success:state.totalSuccess,
            batchIndex:state.batchIndex
          };
        }

        if(!readiness.hasContent){
          return {
            ok:true,
            status:'completed',
            selected:0,
            success:state.totalSuccess,
            totalSuccess:state.totalSuccess,
            batchIndex:state.batchIndex,
            message:
              `좋아요 게시물이 더 이상 없습니다. 총 ${state.totalSuccess.toLocaleString()}개를 정리했습니다.`
          };
        }
      }

      if(state.stopped) return {ok:false,status:'stopped',selected:0,success:state.totalSuccess,totalSuccess:state.totalSuccess,batchIndex:state.batchIndex,message:`사용자가 작업을 중단했습니다. 총 ${state.totalSuccess.toLocaleString()}개를 정리했습니다.`};
      return {ok:true,status:'completed',selected:0,success:state.totalSuccess,totalSuccess:state.totalSuccess,batchIndex:state.batchIndex,message:`계획한 ${state.deleteLimit.toLocaleString()}개 정리를 완료했습니다.`};
    } catch(error) {
      return {ok:false,status:'error',selected:0,success:state.totalSuccess,totalSuccess:state.totalSuccess,batchIndex:state.batchIndex,message:`${error?.message||'정리 작업 중 오류가 발생했습니다.'} 누적 ${state.totalSuccess.toLocaleString()}개를 완료했습니다.`};
    } finally {
      state.running=false; state.paused=false; state.continuous=false; state.batchPlan=[];
    }
  };


  const loadingIndicatorVisible = () => {
    const root =
      document.querySelector('main, [role="main"]') ||
      document.body;

    const candidates = [
      ...root.querySelectorAll(
        '[role="progressbar"], [aria-busy="true"], svg[aria-label*="loading" i], svg[aria-label*="로딩" i]'
      )
    ];

    if (candidates.some((element) => CORE.visible(element))) {
      return true;
    }

    const text = CORE.normalize(
      root.innerText ||
      root.textContent ||
      ''
    );

    return (
      text.includes('로딩 중') ||
      text.includes('불러오는 중') ||
      text.includes('loading')
    );
  };

  const emptyLikesStateVisible = () => {
    const text = CORE.normalize(
      document.body?.innerText ||
      document.body?.textContent ||
      ''
    );

    const phrases = [
      '좋아요 표시한 게시물이 없습니다',
      '좋아요를 누른 게시물이 없습니다',
      '아직 좋아요를 누른 게시물이 없습니다',
      'no liked posts',
      'you haven’t liked any posts',
      "you haven't liked any posts",
      'no likes yet'
    ];

    return phrases.some((phrase) =>
      text.includes(CORE.normalize(phrase))
    );
  };

  const gridReadySignature = (snapshot) => {
    if (!snapshot) return '';
    return [
      snapshot.count,
      ...snapshot.keys.slice(0, 18)
    ].join('|');
  };

  const visibleImagesReady = () => {
    const root =
      document.querySelector('main, [role="main"]') ||
      document.body;

    const images = [...root.querySelectorAll('img')]
      .filter((image) => CORE.visible(image))
      .slice(0, 18);

    if (!images.length) return true;

    const loaded = images.filter((image) =>
      image.complete &&
      (
        image.naturalWidth > 0 ||
        image.getAttribute('src')
      )
    ).length;

    return loaded >= Math.max(
      1,
      Math.ceil(images.length * 0.7)
    );
  };

  const probeRemainingLikedPosts = async ({
    previousSnapshot = state.lastDeletedGridSnapshot
  } = {}) => {
    await leaveSelectionModeIfNeeded();

    const scroller = findScrollable();
    await setScrollPosition(scroller, 0, 'auto');
    await sleep(
      Math.max(180, Math.min(420, activeTiming().scrollWaitMs))
    );

    const startedAt = Date.now();
    let stableReadyChecks = 0;
    let stableEmptyChecks = 0;
    let previousSignature = '';
    let pulse = 0;

    while (!state.stopped) {
      await waitWhilePaused();
      if (state.stopped) {
        return {ok:false,status:'stopped'};
      }

      if (!isLikesPage()) {
        return {
          ok:false,
          status:'page_changed',
          message:
            '좋아요 목록에서 다른 페이지로 이동해 작업을 중단했습니다.'
        };
      }

      if (CORE.detectRestriction(document)) {
        return {
          ok:false,
          status:'blocked',
          message:
            'Instagram 활동 제한 안내가 감지되었습니다.'
        };
      }

      const loading = loadingIndicatorVisible();
      const dialogOpen = Boolean(visibleDialog());
      const selectionActive =
        CORE.selectionModeActive(document) &&
        !CORE.findSelectButton(document);
      const snapshot = gridSnapshot();
      const cards = CORE.findGridCards(document);
      const imagesReady = visibleImagesReady();
      const elapsedSeconds = Math.floor(
        (Date.now() - startedAt) / 1000
      );

      if (emptyLikesStateVisible() && !loading && !dialogOpen) {
        stableEmptyChecks += 1;
      } else {
        stableEmptyChecks = 0;
      }

      if (stableEmptyChecks >= 3) {
        return {
          ok:true,
          hasContent:false,
          empty:true
        };
      }

      const changedFromDeleted =
        !previousSnapshot ||
        gridChanged(previousSnapshot, snapshot);

      const signature = gridReadySignature(snapshot);
      const stableSignature =
        Boolean(signature) &&
        signature === previousSignature;

      const readyNow =
        cards.length > 0 &&
        !loading &&
        !dialogOpen &&
        !selectionActive &&
        imagesReady &&
        changedFromDeleted;

      if (readyNow && stableSignature) {
        stableReadyChecks += 1;
      } else if (readyNow) {
        stableReadyChecks = 1;
      } else {
        stableReadyChecks = 0;
      }

      previousSignature = signature;

      if (stableReadyChecks >= 3) {
        report(
          'list_ready',
          `새 목록 로딩 완료 · 게시물 ${cards.length}개 확인`,
          {
            selected:0,
            visibleCards:cards.length,
            loadingElapsedSeconds:elapsedSeconds
          }
        );

        return {
          ok:true,
          hasContent:true,
          visibleCards:cards.length,
          snapshot
        };
      }

      let statusMessage = '';

      if (loading) {
        statusMessage =
          `Instagram 새 목록을 불러오는 중입니다. ${elapsedSeconds}초 경과`;
      } else if (dialogOpen || selectionActive) {
        statusMessage =
          `이전 선택 화면이 종료되기를 기다립니다. ${elapsedSeconds}초 경과`;
      } else if (cards.length > 0 && !changedFromDeleted) {
        statusMessage =
          `삭제 전 목록이 아직 남아 있습니다. 새 목록을 기다립니다. ${elapsedSeconds}초 경과`;
      } else if (cards.length > 0 && !imagesReady) {
        statusMessage =
          `게시물 이미지 로딩을 기다립니다. ${elapsedSeconds}초 경과`;
      } else if (cards.length > 0) {
        statusMessage =
          `새 목록 안정화 확인 중입니다. ${elapsedSeconds}초 경과`;
      } else {
        statusMessage =
          `새 게시물 목록이 나타나기를 기다립니다. ${elapsedSeconds}초 경과`;
      }

      report(
        'waiting_reload',
        statusMessage,
        {
          selected:0,
          visibleCards:cards.length,
          loadingElapsedSeconds:elapsedSeconds,
          stableReadyChecks
        }
      );

      pulse += 1;

      // Occasionally nudge lazy loading without starting selection.
      if (
        pulse % 16 === 0 &&
        !loading &&
        cards.length === 0
      ) {
        const amount = Math.max(
          100,
          Math.min(window.innerHeight * 0.16, 200)
        );

        if (
          scroller === document.scrollingElement ||
          scroller === document.documentElement ||
          scroller === document.body
        ) {
          window.scrollBy({top:amount,behavior:'smooth'});
          await sleep(
            Math.max(140, activeTiming().scrollWaitMs * 0.5)
          );
          window.scrollTo({top:0,behavior:'auto'});
        } else {
          scroller.scrollBy({top:amount,behavior:'smooth'});
          await sleep(
            Math.max(140, activeTiming().scrollWaitMs * 0.5)
          );
          scroller.scrollTo({top:0,behavior:'auto'});
        }
      }

      // There is intentionally no time limit here.
      // The next batch starts only after Instagram is actually ready.
      await sleep(350);
    }

    return {ok:false,status:'stopped'};
  };

  const runNativeDeleteAll = async (options = {}) => {
    if (state.running) {
      return {
        ok:false,
        status:'busy',
        message:'이미 좋아요 취소 작업이 진행 중입니다.'
      };
    }

    if (!isLikesPage()) {
      return {
        ok:false,
        status:'wrong_page',
        message:'Instagram의 내 활동 > 좋아요 화면에서 실행해주세요.'
      };
    }

    const batchSize = Math.max(
      1,
      Math.min(
        Math.floor(Number(options.batchSize) || 100),
        100
      )
    );

    Object.assign(state, {
      running:true,
      paused:false,
      stopped:false,
      continuous:true,
      batchIndex:0,
      maxBatches:0,
      totalSuccess:0,
      cooldownMs:Math.max(
        5000,
        Math.min(Number(options.cooldownMs)||60000,3600000)
      ),
      deleteLimit:0,
      batchPlan:[],
      strategyMode:'delete_all',
      timing:normalizeTiming(options),
      lastUnlikeSubmittedAt:0,
      lastDeletedGridSnapshot:null
    });

    if (options.resetToTop !== false) {
      report(
        'resetting',
        '전체 삭제를 시작하기 위해 좋아요 목록 맨 위로 이동합니다.',
        {selected:0}
      );
      await setScrollPosition(findScrollable(),0,'auto');
      await sleep(Math.max(260,state.timing.scrollWaitMs));
    }

    try {
      const safetyBatchLimit = 10000;

      let readiness = await probeRemainingLikedPosts({
        previousSnapshot:null
      });

      while (
        !state.stopped &&
        state.batchIndex < safetyBatchLimit
      ) {
        await waitWhilePaused();
        if (state.stopped) break;

        if (!readiness.ok) {
          if (readiness.status === 'stopped') break;
          return {
            ...readiness,
            totalSuccess:state.totalSuccess,
            success:state.totalSuccess,
            batchIndex:state.batchIndex
          };
        }

        if (!readiness.hasContent) {
          return {
            ok:true,
            status:'completed',
            selected:0,
            success:state.totalSuccess,
            totalSuccess:state.totalSuccess,
            batchIndex:state.batchIndex,
            message:
              `좋아요 게시물이 더 이상 없습니다. 총 ${state.totalSuccess.toLocaleString()}개를 정리했습니다.`
          };
        }

        const nextBatch = state.batchIndex + 1;
        const result = await executeOneBatch({
          target:batchSize,
          batchIndex:nextBatch,
          autoScroll:options.autoScroll!==false,
          allowPartial:true
        });

        if (!result.ok) {
          if (
            ['no_cards_selected','select_button_not_found'].includes(
              result.status
            )
          ) {
            const finalProbe = await probeRemainingLikedPosts({
              previousSnapshot:state.lastDeletedGridSnapshot
            });

            if (finalProbe.ok && !finalProbe.hasContent) {
              return {
                ok:true,
                status:'completed',
                selected:0,
                success:state.totalSuccess,
                totalSuccess:state.totalSuccess,
                batchIndex:state.batchIndex,
                message:
                  `좋아요 게시물이 더 이상 없습니다. 총 ${state.totalSuccess.toLocaleString()}개를 정리했습니다.`
              };
            }
          }

          const partial = state.totalSuccess
            ? ` 누적 ${state.totalSuccess.toLocaleString()}개는 완료했습니다.`
            : '';

          return {
            ...result,
            totalSuccess:state.totalSuccess,
            success:state.totalSuccess,
            batchIndex:state.batchIndex,
            message:
              `${result.message || '전체 삭제가 중단되었습니다.'}${partial}`
          };
        }

        const completedThisBatch =
          Number(result.success) ||
          Number(result.selected) ||
          state.target;

        state.batchIndex = nextBatch;
        state.totalSuccess += completedThisBatch;

        report(
          'batch_completed',
          `${state.batchIndex}번째 작업 완료. 누적 ${state.totalSuccess.toLocaleString()}개를 정리했습니다.`,
          {
            selected:0,
            totalSuccess:state.totalSuccess,
            maxBatches:0
          }
        );

        if (completedThisBatch < batchSize) {
          const finalProbe = await probeRemainingLikedPosts({
            previousSnapshot:state.lastDeletedGridSnapshot
          });

          if (finalProbe.ok && !finalProbe.hasContent) {
            return {
              ok:true,
              status:'completed',
              selected:0,
              success:state.totalSuccess,
              totalSuccess:state.totalSuccess,
              batchIndex:state.batchIndex,
              message:
                `좋아요 게시물이 더 이상 없습니다. 총 ${state.totalSuccess.toLocaleString()}개를 정리했습니다.`
            };
          }

          if (!finalProbe.ok) {
            return {
              ...finalProbe,
              totalSuccess:state.totalSuccess,
              success:state.totalSuccess,
              batchIndex:state.batchIndex
            };
          }

          readiness = finalProbe;
        } else {
          const shouldContinue = await waitForCooldown(
            state.cooldownMs
          );
          if (!shouldContinue) break;

          readiness = await probeRemainingLikedPosts({
            previousSnapshot:state.lastDeletedGridSnapshot
          });
        }
      }

      if (state.stopped) {
        return {
          ok:false,
          status:'stopped',
          selected:0,
          success:state.totalSuccess,
          totalSuccess:state.totalSuccess,
          batchIndex:state.batchIndex,
          message:
            `사용자가 전체 삭제를 중단했습니다. 총 ${state.totalSuccess.toLocaleString()}개를 정리했습니다.`
        };
      }

      return {
        ok:false,
        status:'safety_limit',
        selected:0,
        success:state.totalSuccess,
        totalSuccess:state.totalSuccess,
        batchIndex:state.batchIndex,
        message:
          `안전 반복 한도에 도달해 중단했습니다. 누적 ${state.totalSuccess.toLocaleString()}개를 완료했습니다.`
      };
    } catch (error) {
      return {
        ok:false,
        status:'error',
        selected:0,
        success:state.totalSuccess,
        totalSuccess:state.totalSuccess,
        batchIndex:state.batchIndex,
        message:
          `${error?.message || '전체 삭제 중 오류가 발생했습니다.'} 누적 ${state.totalSuccess.toLocaleString()}개를 완료했습니다.`
      };
    } finally {
      state.running=false;
      state.paused=false;
      state.continuous=false;
      state.batchPlan=[];
    }
  };

  const countReport = (phase, message, extra = {}) => {
    chrome.runtime.sendMessage({
      type: 'LIKED_COUNT_PROGRESS',
      progress: {
        phase,
        message,
        counted: countState.counted,
        complete: countState.complete,
        speedMode: countState.timing?.id || 'balanced',
        ...extra
      }
    }).catch(() => {});
  };

  const waitWhileCountPaused = async () => {
    while (countState.paused && !countState.stopped) {
      await sleep(200);
    }
  };

  const scrollPosition = (scroller) => {
    if (
      scroller === document.scrollingElement ||
      scroller === document.documentElement ||
      scroller === document.body
    ) {
      return window.scrollY;
    }
    return scroller?.scrollTop || 0;
  };

  const setScrollPosition = async (
    scroller,
    top,
    behavior = 'auto'
  ) => {
    if (
      scroller === document.scrollingElement ||
      scroller === document.documentElement ||
      scroller === document.body
    ) {
      window.scrollTo({top, behavior});
    } else {
      scroller.scrollTo({top, behavior});
    }
    await sleep(behavior === 'smooth' ? 650 : 250);
  };

  const scrollMetrics = (scroller) => {
    if (
      scroller === document.scrollingElement ||
      scroller === document.documentElement ||
      scroller === document.body
    ) {
      const doc = document.documentElement;
      return {
        top: window.scrollY,
        clientHeight: window.innerHeight,
        scrollHeight: Math.max(
          doc.scrollHeight,
          document.body?.scrollHeight || 0
        )
      };
    }

    return {
      top: scroller.scrollTop,
      clientHeight: scroller.clientHeight,
      scrollHeight: scroller.scrollHeight
    };
  };

  const stableLikedCardKey = (card) => {
    const anchor =
      card.element?.closest?.('a[href]') ||
      card.element?.querySelector?.('a[href]') ||
      card.visual?.closest?.('a[href]');

    const href = anchor?.getAttribute?.('href');
    if (href && CORE.isPostHref(href)) {
      try {
        const url = new URL(href, location.href);
        return `post:${url.pathname.replace(/\/+$/, '')}`;
      } catch {}
    }

    const visual = card.visual;
    const source =
      visual?.currentSrc ||
      visual?.src ||
      visual?.getAttribute?.('src') ||
      visual?.getAttribute?.('poster') ||
      visual?.getAttribute?.('data-src') ||
      '';

    if (source) {
      try {
        const url = new URL(source, location.href);
        return `media:${url.host}${url.pathname}`;
      } catch {
        return `media:${source.split('?')[0]}`;
      }
    }

    const background =
      visual?.style?.backgroundImage ||
      getComputedStyle(visual || card.element)
        .backgroundImage ||
      '';

    if (background && background !== 'none') {
      return `background:${background.replace(/\\?.*?(?=["')])/g, '')}`;
    }

    const label = CORE.normalize(
      visual?.getAttribute?.('alt') ||
      visual?.getAttribute?.('aria-label') ||
      ''
    );

    if (label) {
      return `label:${label}`;
    }

    return '';
  };

  const median = (numbers) => {
    const values = numbers
      .filter((value) => Number.isFinite(value) && value > 0)
      .sort((a, b) => a - b);
    if (!values.length) return 0;
    return values[Math.floor(values.length / 2)];
  };

  const countAllLikedPosts = async (options = {}) => {
    if (state.running || countState.running) {
      return {
        ok: false,
        status: 'busy',
        message: '다른 작업이 이미 진행 중입니다.'
      };
    }

    if (!isLikesPage()) {
      return {
        ok: false,
        status: 'wrong_page',
        message: 'Instagram의 내 활동 > 좋아요 화면에서 실행해주세요.'
      };
    }

    if (CORE.selectionModeActive(document)) {
      return {
        ok: false,
        status: 'selection_mode_active',
        message: '게시물 선택 화면을 먼저 종료한 뒤 개수를 확인해주세요.'
      };
    }

    Object.assign(countState, {
      running: true,
      paused: false,
      stopped: false,
      counted: 0,
      complete: false,
      deleteRequested: false,
      deleteOptions: null,
      timing: normalizeTiming(options)
    });

    const scroller = findScrollable();
    const originalTop = scrollPosition(scroller);
    const keys = new Set();

    let referenceWidth = 0;
    let referenceHeight = 0;
    let stagnantAtBottom = 0;
    let previousCount = 0;
    let pass = 0;
    const maxPasses = Math.max(
      80,
      Math.min(Number(options.maxPasses) || 650, 1000)
    );

    try {
      countReport(
        'count_preparing',
        '좋아요 목록 맨 위로 이동하고 있습니다.'
      );

      await setScrollPosition(scroller, 0, 'auto');
      await sleep(Math.max(220, countState.timing.scrollWaitMs));

      while (
        !countState.stopped &&
        pass < maxPasses
      ) {
        await waitWhileCountPaused();
        if (countState.stopped) break;

        if (!isLikesPage()) {
          return {
            ok: false,
            status: 'page_changed',
            counted: keys.size,
            complete: false,
            message: '좋아요 목록에서 다른 페이지로 이동해 개수 확인을 중단했습니다.'
          };
        }

        const restriction = CORE.detectRestriction(document);
        if (restriction) {
          return {
            ok: false,
            status: 'blocked',
            counted: keys.size,
            complete: false,
            message: 'Instagram 활동 제한 안내가 감지되어 중단했습니다.'
          };
        }

        let cards = CORE.findGridCards(document);

        if (!referenceWidth && cards.length) {
          referenceWidth = median(
            cards.map((card) => card.rect?.width || 0)
          );
          referenceHeight = median(
            cards.map((card) => card.rect?.height || 0)
          );
        }

        if (referenceWidth && referenceHeight) {
          cards = cards.filter((card) => {
            const width = card.rect?.width || 0;
            const height = card.rect?.height || 0;
            return (
              width >= referenceWidth * 0.62 &&
              width <= referenceWidth * 1.45 &&
              height >= referenceHeight * 0.62 &&
              height <= referenceHeight * 1.45
            );
          });
        }

        for (const card of cards) {
          const key = stableLikedCardKey(card);
          if (key) keys.add(key);
        }

        countState.counted = keys.size;
        const metrics = scrollMetrics(scroller);
        const atBottom =
          metrics.top + metrics.clientHeight >=
          metrics.scrollHeight - 18;
        const grew = keys.size > previousCount;

        if (atBottom && !grew) {
          stagnantAtBottom += 1;
        } else if (grew) {
          stagnantAtBottom = 0;
        }

        previousCount = keys.size;
        pass += 1;

        countReport(
          'counting',
          `현재 ${keys.size.toLocaleString()}개 게시물을 확인했습니다.`,
          {
            pass,
            atBottom,
            stagnantAtBottom
          }
        );

        if (atBottom && stagnantAtBottom >= 6) {
          countState.complete = true;
          break;
        }

        const amount = Math.max(
          metrics.clientHeight * 0.82,
          window.innerHeight * 0.72,
          520
        );

        if (
          scroller === document.scrollingElement ||
          scroller === document.documentElement ||
          scroller === document.body
        ) {
          window.scrollBy({
            top: amount,
            behavior: 'smooth'
          });
        } else {
          scroller.scrollBy({
            top: amount,
            behavior: 'smooth'
          });
        }

        await sleep(
          atBottom
            ? countState.timing.bottomWaitMs
            : countState.timing.countScrollWaitMs
        );
      }

      if (countState.stopped) {
        if (countState.deleteRequested && keys.size > 0) {
          return {
            ok: false,
            status: 'handoff_delete',
            counted: keys.size,
            complete: false,
            deleteOptions: countState.deleteOptions || {},
            message:
              `개수 확인을 멈췄습니다. 지금까지 확인한 ${keys.size.toLocaleString()}개 정리를 시작합니다.`
          };
        }

        return {
          ok: false,
          status: 'stopped',
          counted: keys.size,
          complete: false,
          message: `개수 확인을 중단했습니다. 현재까지 최소 ${keys.size.toLocaleString()}개를 확인했습니다.`
        };
      }

      const exact = countState.complete;
      return {
        ok: true,
        status: exact ? 'completed' : 'partial',
        counted: keys.size,
        complete: exact,
        passes: pass,
        message: exact
          ? `좋아요 게시물은 총 ${keys.size.toLocaleString()}개입니다.`
          : `확인 제한에 도달했습니다. 최소 ${keys.size.toLocaleString()}개가 있습니다.`
      };
    } catch (error) {
      return {
        ok: false,
        status: 'error',
        counted: keys.size,
        complete: false,
        message:
          error?.message ||
          `개수 확인 중 오류가 발생했습니다. 최소 ${keys.size.toLocaleString()}개를 확인했습니다.`
      };
    } finally {
      countState.running = false;
      countState.paused = false;

      if (
        options.restorePosition !== false &&
        !countState.deleteRequested &&
        isLikesPage()
      ) {
        countReport(
          'count_restoring',
          '원래 스크롤 위치로 돌아가는 중입니다.',
          {counted: keys.size}
        );
        await setScrollPosition(
          scroller,
          originalTop,
          'auto'
        );
      }
    }
  };

  const runNativeBulkUnlike = async (options = {}) => {
    if (state.running) {
      return {
        ok: false,
        status: 'busy',
        message: '이미 좋아요 취소 작업이 진행 중입니다.'
      };
    }

    if (!isLikesPage()) {
      return {
        ok: false,
        status: 'wrong_page',
        message: 'Instagram의 내 활동 > 좋아요 화면에서 실행해주세요.'
      };
    }

    Object.assign(state, {
      running: true,
      paused: false,
      stopped: false,
      continuous: false,
      batchIndex: 1,
      maxBatches: 1,
      totalSuccess: 0,
      cooldownMs: 0
    });

    try {
      const result = await executeOneBatch({
        target: Math.max(
          1,
          Math.min(Number(options.target) || 5, 20)
        ),
        batchIndex: 1,
        autoScroll: options.autoScroll !== false
      });

      if (result.ok) {
        state.totalSuccess = Number(result.success) || state.target;
      }
      return result;
    } catch (error) {
      return {
        ok: false,
        status: 'error',
        selected: Math.max(
          state.selected,
          state.tentativeSelected
        ),
        message:
          error?.message ||
          '자동 좋아요 취소 중 오류가 발생했습니다.'
      };
    } finally {
      state.running = false;
      state.paused = false;
      state.continuous = false;
    }
  };

  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      if (!message?.type) return;


      if (message.type === 'REQUEST_DELETE_COUNTED') {
        if (!countState.running) {
          sendResponse({
            ok: false,
            counted: countState.counted,
            message: '진행 중인 개수 확인 작업이 없습니다.'
          });
          return;
        }

        if (countState.counted <= 0) {
          sendResponse({
            ok: false,
            counted: 0,
            message: '아직 확인된 게시물이 없습니다.'
          });
          return;
        }

        countState.deleteRequested = true;
        countState.deleteOptions = {
          ...(message.options || {}),
          cooldownMs: Math.max(
            5000,
            Math.min(
              Number(message.options?.cooldownMs) || 60000,
              3600000
            )
          ),
          autoScroll: message.options?.autoScroll !== false
        };
        countState.stopped = true;
        countState.paused = false;

        sendResponse({
          ok: true,
          counted: countState.counted,
          message:
            `${countState.counted.toLocaleString()}개 확인 결과를 정리 작업으로 넘깁니다.`
        });
        return;
      }

      if (message.type === 'START_LIKED_COUNT') {
        if (state.running || countState.running) {
          sendResponse({
            ok: false,
            message: '다른 작업이 이미 진행 중입니다.'
          });
          return;
        }

        sendResponse({ok: true});

        countAllLikedPosts(message.options || {})
          .then((result) => {
            chrome.runtime.sendMessage({
              type: 'LIKED_COUNT_FINISHED',
              result
            }).catch(() => {});
          })
          .catch((error) => {
            chrome.runtime.sendMessage({
              type: 'LIKED_COUNT_FINISHED',
              result: {
                ok: false,
                status: 'error',
                counted: countState.counted,
                complete: false,
                message:
                  error?.message ||
                  '좋아요 개수 확인 중 오류가 발생했습니다.'
              }
            }).catch(() => {});
          });
        return;
      }

      if (message.type === 'RUN_NATIVE_BULK_UNLIKE') {
        runNativeBulkUnlike(message.options || {})
          .then(sendResponse);
        return true;
      }

      if (message.type === 'START_NATIVE_DELETE_ALL') {
        if (state.running) {
          sendResponse({
            ok:false,
            message:'이미 작업이 진행 중입니다.'
          });
          return;
        }

        sendResponse({ok:true});

        runNativeDeleteAll(message.options || {})
          .then((result) =>
            chrome.runtime.sendMessage({
              type:'NATIVE_JOB_FINISHED',
              result
            }).catch(() => {})
          )
          .catch((error) =>
            chrome.runtime.sendMessage({
              type:'NATIVE_JOB_FINISHED',
              result:{
                ok:false,
                status:'error',
                totalSuccess:state.totalSuccess,
                batchIndex:state.batchIndex,
                message:
                  error?.message ||
                  '전체 삭제 실행 중 오류가 발생했습니다.'
              }
            }).catch(() => {})
          );
        return;
      }

      if (
        message.type === 'START_NATIVE_PLAN' ||
        message.type === 'START_NATIVE_CONTINUOUS'
      ) {
        if (state.running) {
          sendResponse({ok: false, message: '이미 작업이 진행 중입니다.'});
          return;
        }

        const options = {...(message.options || {})};
        if (!Array.isArray(options.plan) && message.type === 'START_NATIVE_CONTINUOUS') {
          const size = Math.max(1, Math.min(Number(options.batchSize) || 20, 10000));
          const batches = Math.max(1, Math.min(Number(options.maxBatches) || 1, 10000));
          options.plan = Array.from({length: batches}, () => size);
        }

        sendResponse({ok: true});
        runNativePlan(options)
          .then((result) => chrome.runtime.sendMessage({type: 'NATIVE_JOB_FINISHED', result}).catch(() => {}))
          .catch((error) => chrome.runtime.sendMessage({
            type: 'NATIVE_JOB_FINISHED',
            result: {ok:false,status:'error',totalSuccess:state.totalSuccess,batchIndex:state.batchIndex,message:error?.message||'정리 작업 실행 중 오류가 발생했습니다.'}
          }).catch(() => {}));
        return;
      }


      if (message.type === 'PAUSE_NATIVE_JOB') {
        state.paused = true;
        countState.paused = true;
        sendResponse({ok: true});
        return;
      }

      if (message.type === 'RESUME_NATIVE_JOB') {
        state.paused = false;
        countState.paused = false;
        sendResponse({ok: true});
        return;
      }

      if (message.type === 'STOP_NATIVE_JOB') {
        state.stopped = true;
        state.paused = false;
        countState.stopped = true;
        countState.paused = false;
        sendResponse({ok: true});
        return;
      }

      if (message.type === 'CHECK_NATIVE_PAGE') {
        sendResponse({
          ok: true,
          isLikesPage: isLikesPage(),
          selectButtonFound: Boolean(CORE.findSelectButton(document)),
          visibleCards: CORE.findGridCards(document).length,
          selectionMode: CORE.selectionModeActive(document)
        });
      }
    }
  );
})();

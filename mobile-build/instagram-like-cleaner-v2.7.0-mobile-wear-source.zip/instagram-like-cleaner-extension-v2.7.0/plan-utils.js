(() => {
  const MAX_TOTAL = 10000;
  const MAX_SELECTION = 100;
  const MAX_BATCHES = 10000;

  const int = (value, fallback = 0) => {
    const parsed = Math.floor(Number(value));
    return Number.isFinite(parsed) ? parsed : fallback;
  };

  const clamp = (value, min, max) =>
    Math.min(max, Math.max(min, value));

  const sanitizeTotal = (value) =>
    clamp(int(value, 0), 1, MAX_TOTAL);

  const sanitizeCooldownMs = (value) =>
    clamp(int(value, 60000), 5000, 3600000);


  const SPEED_PROFILES = {
    safe: {
      id: 'safe',
      label: '안전',
      clickDelayMs: 180,
      scrollWaitMs: 900,
      countScrollWaitMs: 760,
      verificationTimeoutMs: 1200
    },
    balanced: {
      id: 'balanced',
      label: '기본',
      clickDelayMs: 65,
      scrollWaitMs: 430,
      countScrollWaitMs: 380,
      verificationTimeoutMs: 700
    },
    fast: {
      id: 'fast',
      label: '고속',
      clickDelayMs: 15,
      scrollWaitMs: 240,
      countScrollWaitMs: 210,
      verificationTimeoutMs: 480
    }
  };

  const sanitizeSpeed = ({
    speedMode = 'balanced',
    clickDelayMs = 65,
    scrollWaitMs = 430
  } = {}) => {
    const mode = ['safe', 'balanced', 'fast', 'custom'].includes(speedMode)
      ? speedMode
      : 'balanced';

    if (mode !== 'custom') {
      return {...SPEED_PROFILES[mode]};
    }

    const click = clamp(int(clickDelayMs, 65), 0, 2000);
    const scroll = clamp(int(scrollWaitMs, 430), 120, 5000);

    return {
      id: 'custom',
      label: '직접 설정',
      clickDelayMs: click,
      scrollWaitMs: scroll,
      countScrollWaitMs: scroll,
      verificationTimeoutMs: clamp(click + 420, 380, 2500)
    };
  };

  const chunkPlan = (total, batchSize) => {
    const plan = [];
    let remaining = total;
    const size = clamp(
      int(batchSize, 20),
      1,
      Math.min(total, MAX_SELECTION)
    );
    while (remaining > 0 && plan.length < MAX_BATCHES) {
      const current = Math.min(size, remaining, MAX_SELECTION);
      plan.push(current);
      remaining -= current;
    }
    return plan;
  };

  const roundsPlan = (total, rounds) => {
    const requested = clamp(int(rounds, 1), 1, total);
    const minimumForLimit = Math.ceil(total / MAX_SELECTION);
    const count = clamp(
      Math.max(requested, minimumForLimit),
      1,
      total
    );
    const base = Math.floor(total / count);
    const remainder = total % count;
    return Array.from({length: count}, (_, index) =>
      Math.min(
        MAX_SELECTION,
        base + (index < remainder ? 1 : 0)
      )
    );
  };

  const buildPlan = ({mode, total, batchSize, rounds}) => {
    const safeTotal = sanitizeTotal(total);
    if (mode === 'all') {
      return chunkPlan(safeTotal, MAX_SELECTION);
    }
    if (mode === 'rounds') {
      return roundsPlan(safeTotal, rounds);
    }
    return chunkPlan(safeTotal, batchSize);
  };

  const sum = (plan) => plan.reduce((acc, value) => acc + value, 0);

  const estimate = ({plan, cooldownMs, speed}) => {
    const clean = (Array.isArray(plan) ? plan : [])
      .map((value) => clamp(int(value, 0), 1, MAX_TOTAL))
      .filter(Boolean);
    const total = sum(clean);
    const batches = clean.length;
    const pauses = Math.max(0, batches - 1);
    const cooldown = sanitizeCooldownMs(cooldownMs);
    const timing = sanitizeSpeed(speed || {});

    const profileRanges = {
      safe: {low: 650, high: 1250, batchLow: 5200, batchHigh: 13000},
      balanced: {low: 260, high: 650, batchLow: 3600, batchHigh: 8500},
      fast: {low: 120, high: 420, batchLow: 2800, batchHigh: 6500}
    };

    const range = timing.id === 'custom'
      ? {
          low: Math.max(90, timing.clickDelayMs + 100),
          high: Math.max(260, timing.clickDelayMs + timing.verificationTimeoutMs * 0.72),
          batchLow: 2500 + timing.scrollWaitMs * 1.4,
          batchHigh: 6000 + timing.scrollWaitMs * 3
        }
      : profileRanges[timing.id];

    const lowMs =
      total * range.low +
      batches * range.batchLow +
      pauses * cooldown;
    const highMs =
      total * range.high +
      batches * range.batchHigh +
      pauses * cooldown;

    return {
      total,
      batches,
      pauses,
      lowMs,
      highMs,
      speed: timing
    };
  };

  const formatDuration = (ms) => {
    const seconds = Math.max(0, Math.round(ms / 1000));
    if (seconds < 60) return `${seconds}초`;
    const minutes = Math.floor(seconds / 60);
    const remainSeconds = seconds % 60;
    if (minutes < 60) {
      return remainSeconds ? `${minutes}분 ${remainSeconds}초` : `${minutes}분`;
    }
    const hours = Math.floor(minutes / 60);
    const remainMinutes = minutes % 60;
    return remainMinutes ? `${hours}시간 ${remainMinutes}분` : `${hours}시간`;
  };

  const describe = ({mode, plan, rounds}) => {
    const clean = Array.isArray(plan) ? plan : [];
    const total = sum(clean);
    if (!clean.length) return '';

    if (mode === 'all') {
      const last = clean[clean.length - 1];
      return last === MAX_SELECTION
        ? `Instagram 한도에 맞춰 ${MAX_SELECTION}개씩 ${clean.length.toLocaleString()}회`
        : `Instagram 한도에 맞춰 최대 ${MAX_SELECTION}개씩 ${clean.length.toLocaleString()}회 · 마지막 ${last.toLocaleString()}개`;
    }

    if (mode === 'rounds') {
      const min = Math.min(...clean);
      const max = Math.max(...clean);
      const each = min === max
        ? `회당 ${min.toLocaleString()}개`
        : `회당 ${min.toLocaleString()}~${max.toLocaleString()}개`;
      const requested = clamp(int(rounds, clean.length), 1, total);

      if (clean.length > requested) {
        return `요청 ${requested.toLocaleString()}회 → 선택 한도로 ${clean.length.toLocaleString()}회 자동 보정 · ${each}`;
      }
      return `${clean.length.toLocaleString()}회 분할 · ${each}`;
    }

    const first = clean[0];
    const last = clean[clean.length - 1];
    return last === first
      ? `${first.toLocaleString()}개씩 ${clean.length.toLocaleString()}회`
      : `${first.toLocaleString()}개씩 ${clean.length.toLocaleString()}회 · 마지막 ${last.toLocaleString()}개`;
  };

  globalThis.__ILC_PLAN__ = {
    MAX_TOTAL,
    MAX_SELECTION,
    sanitizeTotal,
    sanitizeCooldownMs,
    sanitizeSpeed,
    SPEED_PROFILES,
    buildPlan,
    estimate,
    formatDuration,
    describe,
    sum
  };
})();

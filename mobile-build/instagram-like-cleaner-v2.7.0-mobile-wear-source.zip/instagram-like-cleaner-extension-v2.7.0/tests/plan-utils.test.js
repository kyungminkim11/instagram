const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '..', 'plan-utils.js'), 'utf8');
const context = {globalThis: {}};
vm.createContext(context);
vm.runInContext(source, context);
const plan = context.globalThis.__ILC_PLAN__;

assert.deepEqual([...plan.buildPlan({mode: 'custom', total: 250, batchSize: 100})], [100, 100, 50]);
assert.equal(plan.sum(plan.buildPlan({mode: 'rounds', total: 1800, rounds: 10})), 1800);
assert.equal(plan.buildPlan({mode: 'rounds', total: 1800, rounds: 10}).length, 18);
assert.ok(plan.buildPlan({mode: 'all', total: 301}).every((value) => value <= 100));
assert.equal(plan.sanitizeSpeed({speedMode: 'fast'}).clickDelayMs, 15);
assert.equal(plan.sanitizeCooldownMs(1), 5000);

console.log('plan-utils: ok');

const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const nativeMessages = [];
const contentMessages = [];
let nativeMessageListener;
let runtimeMessageListener;

const nativePort = {
  onMessage: {addListener(listener) { nativeMessageListener = listener; }},
  onDisconnect: {addListener() {}},
  postMessage(message) { nativeMessages.push(message); }
};

const browser = {
  runtime: {
    connectNative() { return nativePort; },
    onMessage: {addListener(listener) { runtimeMessageListener = listener; }}
  },
  tabs: {
    async query() {
      return [{id: 1, active: true, url: 'https://www.instagram.com/your_activity/interactions/likes/'}];
    },
    async sendMessage(tabId, message) {
      contentMessages.push({tabId, message});
      return {ok: true};
    },
    async update() { return {id: 1}; },
    async create() { return {id: 2}; }
  }
};

const source = fs.readFileSync(
  path.join(__dirname, '..', 'shared-engine', 'geckoview-extension', 'background.js'),
  'utf8'
);
const context = {
  browser,
  console,
  setTimeout() { return 1; },
  clearTimeout() {}
};
vm.createContext(context);
vm.runInContext(source, context);

(async () => {
  assert.equal(typeof nativeMessageListener, 'function');
  await nativeMessageListener({
    requestId: 'r1',
    type: 'START_DELETE_ALL_JOB',
    options: {batchSize: 80, cooldownMs: 30000, speedMode: 'balanced'}
  });
  await new Promise((resolve) => setImmediate(resolve));

  assert.equal(contentMessages.length, 1);
  assert.equal(contentMessages[0].message.type, 'START_NATIVE_DELETE_ALL');
  assert.equal(contentMessages[0].message.options.batchSize, 80);
  assert.ok(nativeMessages.some((item) => item.kind === 'response' && item.requestId === 'r1'));

  await runtimeMessageListener({type: 'NATIVE_JOB_PROGRESS', progress: {selected: 4}});
  assert.ok(nativeMessages.some((item) => item.kind === 'event' && item.message.type === 'NATIVE_JOB_PROGRESS'));

  console.log('geckoview-background: ok');
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

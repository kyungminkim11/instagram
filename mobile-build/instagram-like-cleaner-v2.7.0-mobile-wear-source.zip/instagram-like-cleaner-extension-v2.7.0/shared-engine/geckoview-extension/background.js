(() => {
  const LIKES_URL = 'https://www.instagram.com/your_activity/interactions/likes/';
  const NATIVE_APP = 'ilc_mobile';
  const EVENT_TYPES = new Set([
    'NATIVE_JOB_PROGRESS',
    'NATIVE_JOB_FINISHED',
    'LIKED_COUNT_PROGRESS',
    'LIKED_COUNT_FINISHED'
  ]);

  let nativePort = null;
  let reconnectTimer = null;

  const postNative = (payload) => {
    try {
      nativePort?.postMessage(payload);
      return true;
    } catch {
      return false;
    }
  };

  const connectedTabs = async () => {
    const tabs = await browser.tabs.query({});
    return tabs.filter((tab) =>
      typeof tab.url === 'string' &&
      tab.url.startsWith('https://www.instagram.com/')
    );
  };

  const targetTab = async () => {
    const tabs = await connectedTabs();
    return tabs.find((tab) => tab.active) || tabs[0] || null;
  };

  const openLikesPage = async () => {
    const tab = await targetTab();
    if (tab?.id != null) {
      await browser.tabs.update(tab.id, {url: LIKES_URL, active: true});
      return {ok: true, tabId: tab.id};
    }
    const created = await browser.tabs.create({url: LIKES_URL, active: true});
    return {ok: true, tabId: created?.id ?? null};
  };

  const sendToContent = async (message) => {
    const tab = await targetTab();
    if (!tab?.id) {
      return {
        ok: false,
        message: 'Instagram 탭을 찾지 못했습니다. 휴대폰 앱에서 좋아요 화면을 먼저 열어주세요.'
      };
    }

    if (!String(tab.url || '').includes('/your_activity/interactions/likes')) {
      return {
        ok: false,
        message: '현재 화면이 Instagram 좋아요 목록이 아닙니다.'
      };
    }

    try {
      return await browser.tabs.sendMessage(tab.id, message);
    } catch (error) {
      return {
        ok: false,
        message: error?.message || 'Instagram 페이지와 통신하지 못했습니다. 페이지를 새로고침해주세요.'
      };
    }
  };

  const routeCommand = async (command) => {
    const type = command?.type;
    const options = command?.options || {};

    if (type === 'HELLO') {
      return {ok: true, ready: true};
    }
    if (type === 'OPEN_LIKES_PAGE') {
      return openLikesPage();
    }
    if (type === 'CHECK_NATIVE_PAGE') {
      return sendToContent({type: 'CHECK_NATIVE_PAGE'});
    }
    if (type === 'START_COUNT_JOB') {
      return sendToContent({
        type: 'START_LIKED_COUNT',
        options: {
          restorePosition: true,
          maxPasses: 650,
          speedMode: options.speedMode,
          clickDelayMs: options.clickDelayMs,
          scrollWaitMs: options.scrollWaitMs
        }
      });
    }
    if (type === 'START_DELETE_PLAN_JOB') {
      return sendToContent({
        type: 'START_NATIVE_PLAN',
        options: {
          plan: Array.isArray(options.plan) ? options.plan : [],
          cooldownMs: options.cooldownMs,
          autoScroll: options.autoScroll !== false,
          resetToTop: true,
          strategyMode: options.strategyMode || 'custom',
          speedMode: options.speedMode,
          clickDelayMs: options.clickDelayMs,
          scrollWaitMs: options.scrollWaitMs
        }
      });
    }
    if (type === 'START_DELETE_ALL_JOB') {
      return sendToContent({
        type: 'START_NATIVE_DELETE_ALL',
        options: {
          batchSize: options.batchSize,
          cooldownMs: options.cooldownMs,
          autoScroll: options.autoScroll !== false,
          resetToTop: true,
          speedMode: options.speedMode,
          clickDelayMs: options.clickDelayMs,
          scrollWaitMs: options.scrollWaitMs
        }
      });
    }
    if (
      type === 'PAUSE_NATIVE_JOB' ||
      type === 'RESUME_NATIVE_JOB' ||
      type === 'STOP_NATIVE_JOB'
    ) {
      return sendToContent({type});
    }

    return {ok: false, message: `지원하지 않는 명령입니다: ${String(type || '')}`};
  };

  const handleNativeMessage = async (command) => {
    const requestId = command?.requestId || null;
    try {
      const response = await routeCommand(command || {});
      postNative({kind: 'response', requestId, response: response || {ok: true}});
    } catch (error) {
      postNative({
        kind: 'response',
        requestId,
        response: {
          ok: false,
          message: error?.message || '모바일 브리지 명령 처리 중 오류가 발생했습니다.'
        }
      });
    }
  };

  const connectNative = () => {
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }

    try {
      nativePort = browser.runtime.connectNative(NATIVE_APP);
      nativePort.onMessage.addListener(handleNativeMessage);
      nativePort.onDisconnect.addListener(() => {
        nativePort = null;
        reconnectTimer = setTimeout(connectNative, 1500);
      });
      postNative({kind: 'event', message: {type: 'BRIDGE_READY'}});
    } catch {
      nativePort = null;
      reconnectTimer = setTimeout(connectNative, 1500);
    }
  };

  browser.runtime.onMessage.addListener((message) => {
    if (!message?.type || !EVENT_TYPES.has(message.type)) return undefined;
    postNative({kind: 'event', message});
    return Promise.resolve({ok: true});
  });

  connectNative();
})();

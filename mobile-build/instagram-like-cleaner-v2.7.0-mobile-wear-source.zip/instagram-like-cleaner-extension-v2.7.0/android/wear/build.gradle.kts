plugins {
    id("com.android.application")
}

android {
    namespace = "co.kr.lavalabs.instagramcleaner.wear"
    compileSdk = 35

    defaultConfig {
        applicationId = "co.kr.lavalabs.instagramcleaner"
        minSdk = 30
        targetSdk = 35
        versionCode = 270
        versionName = "2.7.0-wear.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation(project(":common"))
    implementation("androidx.wear:wear:1.3.0")
    implementation("androidx.core:core:1.15.0")
    implementation("com.google.android.gms:play-services-wearable:19.0.0")
}

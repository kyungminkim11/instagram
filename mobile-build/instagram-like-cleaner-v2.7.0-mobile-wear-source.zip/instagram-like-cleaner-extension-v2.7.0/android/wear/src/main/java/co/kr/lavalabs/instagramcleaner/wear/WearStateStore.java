package co.kr.lavalabs.instagramcleaner.wear;

import android.content.Context;

import co.kr.lavalabs.instagramcleaner.common.JobSnapshot;

public final class WearStateStore {
    private static final String PREFS = "wear_cleaner_state";
    private static final String KEY = "snapshot";

    private WearStateStore() {}

    public static void save(Context context, JobSnapshot snapshot) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY, snapshot.toJson())
                .apply();
    }

    public static JobSnapshot load(Context context) {
        return JobSnapshot.fromJson(
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .getString(KEY, null)
        );
    }
}

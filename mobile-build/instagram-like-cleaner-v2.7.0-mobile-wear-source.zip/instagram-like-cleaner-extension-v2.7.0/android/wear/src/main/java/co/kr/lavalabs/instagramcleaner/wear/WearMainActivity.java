package co.kr.lavalabs.instagramcleaner.wear;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.wearable.DataClient;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;

import java.nio.charset.StandardCharsets;

import co.kr.lavalabs.instagramcleaner.common.BridgeContract;
import co.kr.lavalabs.instagramcleaner.common.JobSnapshot;

public final class WearMainActivity extends Activity implements DataClient.OnDataChangedListener {
    private TextView status;
    private TextView count;
    private TextView message;
    private ProgressBar progress;
    private Button start;
    private Button pause;
    private Button stop;
    private JobSnapshot snapshot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wear_main);

        status = findViewById(R.id.wearStatus);
        count = findViewById(R.id.wearCount);
        message = findViewById(R.id.wearMessage);
        progress = findViewById(R.id.wearProgress);
        start = findViewById(R.id.wearStart);
        pause = findViewById(R.id.wearPause);
        stop = findViewById(R.id.wearStop);

        snapshot = WearStateStore.load(this);
        render(snapshot);

        start.setOnClickListener(view -> sendCommand(BridgeContract.REMOTE_START_DELETE_ALL));
        pause.setOnClickListener(view -> sendCommand(
                snapshot.isPaused() ? BridgeContract.REMOTE_RESUME : BridgeContract.REMOTE_PAUSE
        ));
        stop.setOnClickListener(view -> sendCommand(BridgeContract.REMOTE_STOP));
    }

    @Override
    protected void onResume() {
        super.onResume();
        Wearable.getDataClient(this).addListener(this);
        refreshState();
    }

    @Override
    protected void onPause() {
        Wearable.getDataClient(this).removeListener(this);
        super.onPause();
    }

    private void refreshState() {
        Uri uri = Uri.parse("wear://*" + BridgeContract.DATA_STATE_PATH);
        Wearable.getDataClient(this)
                .getDataItems(uri, DataClient.FILTER_PREFIX)
                .addOnSuccessListener(items -> {
                    for (int i = 0; i < items.getCount(); i++) {
                        String raw = DataMapItem.fromDataItem(items.get(i))
                                .getDataMap()
                                .getString("snapshot");
                        applySnapshot(JobSnapshot.fromJson(raw));
                    }
                    items.release();
                });
    }

    @Override
    public void onDataChanged(DataEventBuffer events) {
        for (DataEvent event : events) {
            if (event.getType() != DataEvent.TYPE_CHANGED) continue;
            if (!BridgeContract.DATA_STATE_PATH.equals(event.getDataItem().getUri().getPath())) continue;
            String raw = DataMapItem.fromDataItem(event.getDataItem())
                    .getDataMap()
                    .getString("snapshot");
            applySnapshot(JobSnapshot.fromJson(raw));
        }
    }

    private void applySnapshot(JobSnapshot next) {
        snapshot = next;
        WearStateStore.save(this, next);
        runOnUiThread(() -> render(next));
    }

    private void render(JobSnapshot state) {
        status.setText(statusLabel(state));
        if ("count".equals(state.mode)) {
            count.setText(String.format("%,d개 확인", state.counted));
        } else {
            count.setText(String.format("%,d개 완료", state.totalSuccess));
        }
        message.setText(state.message);
        progress.setIndeterminate(state.isActive() && ("count".equals(state.mode) || "delete_all".equals(state.mode)));
        if (!progress.isIndeterminate()) progress.setProgress(state.progressPercent());

        boolean active = state.isActive();
        start.setEnabled(!active);
        pause.setEnabled(active);
        stop.setEnabled(active);
        pause.setText(state.isPaused() ? "재개" : "일시정지");
    }

    private String statusLabel(JobSnapshot state) {
        if (!state.bridgeReady) return "휴대폰 앱 연결 필요";
        if (state.isPaused()) return "일시정지";
        if ("running".equals(state.status)) {
            if ("waiting_reload".equals(state.phase)) return "Instagram 로딩 대기";
            if ("cooling".equals(state.phase)) return "휴식 중";
            if ("count".equals(state.mode)) return "개수 확인 중";
            return "정리 중";
        }
        return switch (state.status) {
            case "completed" -> "완료";
            case "stopped" -> "중단됨";
            case "error" -> "오류";
            case "blocked" -> "활동 제한";
            default -> "대기 중";
        };
    }

    private void sendCommand(String command) {
        Wearable.getNodeClient(this).getConnectedNodes()
                .addOnSuccessListener(nodes -> {
                    if (nodes.isEmpty()) {
                        Toast.makeText(this, "연결된 휴대폰이 없습니다.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    byte[] payload = command.getBytes(StandardCharsets.UTF_8);
                    for (Node node : nodes) {
                        Wearable.getMessageClient(this).sendMessage(
                                node.getId(),
                                BridgeContract.MESSAGE_COMMAND_PATH,
                                payload
                        );
                    }
                    Toast.makeText(this, "휴대폰으로 명령을 보냈습니다.", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(error -> Toast.makeText(
                        this,
                        "휴대폰과 통신하지 못했습니다.",
                        Toast.LENGTH_SHORT
                ).show());
    }
}

package co.kr.lavalabs.instagramcleaner.wear;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.WearableListenerService;

import co.kr.lavalabs.instagramcleaner.common.BridgeContract;
import co.kr.lavalabs.instagramcleaner.common.JobSnapshot;

public final class WearStateService extends WearableListenerService {
    @Override
    public void onDataChanged(DataEventBuffer events) {
        for (DataEvent event : events) {
            if (event.getType() != DataEvent.TYPE_CHANGED) continue;
            if (!BridgeContract.DATA_STATE_PATH.equals(event.getDataItem().getUri().getPath())) continue;
            String raw = DataMapItem.fromDataItem(event.getDataItem())
                    .getDataMap()
                    .getString("snapshot");
            WearStateStore.save(this, JobSnapshot.fromJson(raw));
        }
    }
}

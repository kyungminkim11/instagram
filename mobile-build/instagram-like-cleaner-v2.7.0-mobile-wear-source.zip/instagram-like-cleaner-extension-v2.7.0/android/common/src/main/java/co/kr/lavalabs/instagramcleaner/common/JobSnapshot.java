package co.kr.lavalabs.instagramcleaner.common;

import org.json.JSONException;
import org.json.JSONObject;

public final class JobSnapshot {
    public String mode = "idle";
    public String status = "idle";
    public String phase = "idle";
    public String message = "Instagram 좋아요 화면을 열어 시작하세요.";
    public int target = 0;
    public int selected = 0;
    public int counted = 0;
    public int totalSuccess = 0;
    public int batchIndex = 0;
    public int maxBatches = 0;
    public int cooldownRemaining = 0;
    public boolean bridgeReady = false;
    public long updatedAt = System.currentTimeMillis();

    public static JobSnapshot idle() {
        return new JobSnapshot();
    }

    public boolean isActive() {
        return "running".equals(status) || "paused".equals(status);
    }

    public boolean isPaused() {
        return "paused".equals(status);
    }

    public int progressPercent() {
        if ("count".equals(mode) && isActive()) return 0;
        int total = Math.max(target, 0);
        if (maxBatches > 1 && target > 0) total = Math.max(total, target * maxBatches);
        if (total <= 0) return 0;
        int done = Math.max(0, totalSuccess + selected);
        return Math.max(0, Math.min(100, Math.round(done * 100f / total)));
    }

    public JSONObject toJsonObject() {
        JSONObject json = new JSONObject();
        try {
            json.put("mode", mode);
            json.put("status", status);
            json.put("phase", phase);
            json.put("message", message);
            json.put("target", target);
            json.put("selected", selected);
            json.put("counted", counted);
            json.put("totalSuccess", totalSuccess);
            json.put("batchIndex", batchIndex);
            json.put("maxBatches", maxBatches);
            json.put("cooldownRemaining", cooldownRemaining);
            json.put("bridgeReady", bridgeReady);
            json.put("updatedAt", updatedAt);
        } catch (JSONException ignored) {
        }
        return json;
    }

    public String toJson() {
        return toJsonObject().toString();
    }

    public static JobSnapshot fromJson(String raw) {
        if (raw == null || raw.isBlank()) return idle();
        try {
            return fromJsonObject(new JSONObject(raw));
        } catch (JSONException ignored) {
            return idle();
        }
    }

    public static JobSnapshot fromJsonObject(JSONObject json) {
        JobSnapshot snapshot = idle();
        snapshot.mode = json.optString("mode", snapshot.mode);
        snapshot.status = json.optString("status", snapshot.status);
        snapshot.phase = json.optString("phase", snapshot.phase);
        snapshot.message = json.optString("message", snapshot.message);
        snapshot.target = Math.max(0, json.optInt("target", 0));
        snapshot.selected = Math.max(0, json.optInt("selected", 0));
        snapshot.counted = Math.max(0, json.optInt("counted", 0));
        snapshot.totalSuccess = Math.max(0, json.optInt("totalSuccess", 0));
        snapshot.batchIndex = Math.max(0, json.optInt("batchIndex", 0));
        snapshot.maxBatches = Math.max(0, json.optInt("maxBatches", 0));
        snapshot.cooldownRemaining = Math.max(0, json.optInt("cooldownRemaining", 0));
        snapshot.bridgeReady = json.optBoolean("bridgeReady", false);
        snapshot.updatedAt = json.optLong("updatedAt", System.currentTimeMillis());
        return snapshot;
    }

    public JobSnapshot copy() {
        return fromJson(toJson());
    }
}

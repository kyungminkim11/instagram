package co.kr.lavalabs.instagramcleaner.common;

public final class BridgeContract {
    private BridgeContract() {}

    public static final String LIKES_URL =
            "https://www.instagram.com/your_activity/interactions/likes/";

    public static final String EXTENSION_LOCATION =
            "resource://android/assets/geckoview-extension/";
    public static final String EXTENSION_ID = "instagram-like-cleaner@lavalabs.co.kr";
    public static final String NATIVE_APP_ID = "ilc_mobile";

    public static final String DATA_STATE_PATH = "/instagram-cleaner/state";
    public static final String MESSAGE_COMMAND_PATH = "/instagram-cleaner/command";

    public static final String CMD_OPEN_LIKES = "OPEN_LIKES_PAGE";
    public static final String CMD_CHECK_PAGE = "CHECK_NATIVE_PAGE";
    public static final String CMD_START_COUNT = "START_COUNT_JOB";
    public static final String CMD_START_PLAN = "START_DELETE_PLAN_JOB";
    public static final String CMD_START_DELETE_ALL = "START_DELETE_ALL_JOB";
    public static final String CMD_PAUSE = "PAUSE_NATIVE_JOB";
    public static final String CMD_RESUME = "RESUME_NATIVE_JOB";
    public static final String CMD_STOP = "STOP_NATIVE_JOB";

    public static final String REMOTE_START_DELETE_ALL = "START_DELETE_ALL";
    public static final String REMOTE_PAUSE = "PAUSE";
    public static final String REMOTE_RESUME = "RESUME";
    public static final String REMOTE_STOP = "STOP";
    public static final String REMOTE_OPEN_LIKES = "OPEN_LIKES";

    public static final String EVENT_NATIVE_PROGRESS = "NATIVE_JOB_PROGRESS";
    public static final String EVENT_NATIVE_FINISHED = "NATIVE_JOB_FINISHED";
    public static final String EVENT_COUNT_PROGRESS = "LIKED_COUNT_PROGRESS";
    public static final String EVENT_COUNT_FINISHED = "LIKED_COUNT_FINISHED";
}

plugins {
    id("com.android.library")
}

android {
    namespace = "co.kr.lavalabs.instagramcleaner.common"
    compileSdk = 35

    defaultConfig {
        minSdk = 26
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

plugins {
    id("com.android.application")
}

android {
    namespace = "co.kr.lavalabs.instagramcleaner.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "co.kr.lavalabs.instagramcleaner"
        minSdk = 26
        targetSdk = 35
        versionCode = 270
        versionName = "2.7.0-mobile.1"
    }

    sourceSets {
        getByName("main").assets.srcDir(rootProject.file("../shared-engine"))
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    implementation(project(":common"))
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core:1.15.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.android.gms:play-services-wearable:19.0.0")
    implementation("org.mozilla.geckoview:geckoview:${property("geckoviewVersion")}")
}

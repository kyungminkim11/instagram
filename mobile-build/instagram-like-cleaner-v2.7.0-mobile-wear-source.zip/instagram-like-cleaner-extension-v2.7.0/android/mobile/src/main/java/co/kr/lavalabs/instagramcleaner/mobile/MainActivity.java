package co.kr.lavalabs.instagramcleaner.mobile;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import org.json.JSONObject;
import org.mozilla.geckoview.GeckoView;

import co.kr.lavalabs.instagramcleaner.common.JobSnapshot;

public final class MainActivity extends AppCompatActivity implements CleanerController.Listener {
    private CleanerController controller;
    private GeckoBridge bridge;

    private TextView bridgeStatus;
    private TextView jobStatus;
    private TextView jobNumbers;
    private TextView jobMessage;
    private LinearProgressIndicator jobProgress;
    private EditText totalInput;
    private EditText batchInput;
    private EditText cooldownInput;
    private RadioGroup speedGroup;
    private MaterialButton countButton;
    private MaterialButton startPlanButton;
    private MaterialButton startAllButton;
    private MaterialButton pauseButton;
    private MaterialButton stopButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        requestNotificationPermission();

        controller = CleanerController.get(this);
        GeckoView geckoView = findViewById(R.id.geckoView);
        bridge = new GeckoBridge(this, geckoView, controller);
        controller.attachBridge(bridge);
        controller.addListener(this);

        loadSettings();
        bindActions();
    }

    private void bindViews() {
        bridgeStatus = findViewById(R.id.bridgeStatus);
        jobStatus = findViewById(R.id.jobStatus);
        jobNumbers = findViewById(R.id.jobNumbers);
        jobMessage = findViewById(R.id.jobMessage);
        jobProgress = findViewById(R.id.jobProgress);
        totalInput = findViewById(R.id.totalInput);
        batchInput = findViewById(R.id.batchInput);
        cooldownInput = findViewById(R.id.cooldownInput);
        speedGroup = findViewById(R.id.speedGroup);
        countButton = findViewById(R.id.countButton);
        startPlanButton = findViewById(R.id.startPlanButton);
        startAllButton = findViewById(R.id.startAllButton);
        pauseButton = findViewById(R.id.pauseButton);
        stopButton = findViewById(R.id.stopButton);
    }

    private void bindActions() {
        findViewById(R.id.openLikesButton).setOnClickListener(view -> controller.openLikesPage());
        countButton.setOnClickListener(view -> controller.startCount(readSettings()));
        startPlanButton.setOnClickListener(view -> {
            CleanerSettings settings = readSettings();
            new MaterialAlertDialogBuilder(this)
                    .setTitle("설정 수량을 정리할까요?")
                    .setMessage(String.format(
                            "%,d개를 한 번에 최대 %,d개씩 정리합니다. 작업 사이 휴식은 %,d초입니다.",
                            settings.total,
                            settings.batchSize,
                            settings.cooldownSeconds
                    ))
                    .setNegativeButton("취소", null)
                    .setPositiveButton("정리 시작", (dialog, which) -> controller.startPlan(settings))
                    .show();
        });
        startAllButton.setOnClickListener(view -> {
            CleanerSettings settings = readSettings();
            new MaterialAlertDialogBuilder(this)
                    .setTitle("좋아요를 끝까지 전체 삭제할까요?")
                    .setMessage(String.format(
                            "%,d개씩 반복합니다. Instagram 로딩 완료를 확인한 뒤 다음 묶음을 진행하며, 언제든 일시정지하거나 중단할 수 있습니다.",
                            settings.batchSize
                    ))
                    .setNegativeButton("취소", null)
                    .setPositiveButton("전체 삭제 시작", (dialog, which) -> controller.startDeleteAll(settings))
                    .show();
        });
        pauseButton.setOnClickListener(view -> {
            if (controller.state().isPaused()) controller.resume();
            else controller.pause();
        });
        stopButton.setOnClickListener(view -> controller.stop());
    }

    private void loadSettings() {
        CleanerSettings settings = CleanerSettings.load(this);
        totalInput.setText(String.valueOf(settings.total));
        batchInput.setText(String.valueOf(settings.batchSize));
        cooldownInput.setText(String.valueOf(settings.cooldownSeconds));
        if ("safe".equals(settings.speedMode)) speedGroup.check(R.id.speedSafe);
        else if ("fast".equals(settings.speedMode)) speedGroup.check(R.id.speedFast);
        else speedGroup.check(R.id.speedBalanced);
    }

    private CleanerSettings readSettings() {
        CleanerSettings settings = new CleanerSettings();
        settings.total = parseInt(totalInput, 100, 1, 10000);
        settings.batchSize = parseInt(batchInput, 100, 1, 100);
        settings.cooldownSeconds = parseInt(cooldownInput, 60, 5, 3600);
        int selectedSpeed = speedGroup.getCheckedRadioButtonId();
        settings.speedMode = selectedSpeed == R.id.speedSafe
                ? "safe"
                : selectedSpeed == R.id.speedFast ? "fast" : "balanced";
        settings.save(this);
        return settings;
    }

    private int parseInt(EditText input, int fallback, int min, int max) {
        try {
            int value = Integer.parseInt(String.valueOf(input.getText()).trim());
            value = CleanerSettings.clamp(value, min, max);
            input.setText(String.valueOf(value));
            return value;
        } catch (NumberFormatException error) {
            input.setText(String.valueOf(fallback));
            return fallback;
        }
    }

    @Override
    public void onStateChanged(@NonNull JobSnapshot state) {
        bridgeStatus.setText(state.bridgeReady ? "모바일 정리 엔진 연결됨" : "브라우저 연결 준비 중");
        jobStatus.setText(statusLabel(state));
        jobMessage.setText(state.message);

        if ("count".equals(state.mode)) {
            jobNumbers.setText(String.format("%,d개 확인", state.counted));
        } else if ("delete_all".equals(state.mode)) {
            jobNumbers.setText(String.format("%,d개 완료 · %d번째 묶음", state.totalSuccess, state.batchIndex));
        } else {
            jobNumbers.setText(String.format("%,d개 완료 · %,d개 선택", state.totalSuccess, state.selected));
        }

        boolean indeterminate = state.isActive()
                && ("count".equals(state.mode) || "delete_all".equals(state.mode));
        jobProgress.setIndeterminate(indeterminate);
        if (!indeterminate) jobProgress.setProgressCompat(state.progressPercent(), true);

        boolean active = state.isActive();
        countButton.setEnabled(!active && state.bridgeReady);
        startPlanButton.setEnabled(!active && state.bridgeReady);
        startAllButton.setEnabled(!active && state.bridgeReady);
        pauseButton.setEnabled(active);
        stopButton.setEnabled(active);
        pauseButton.setText(state.isPaused() ? "재개" : "일시정지");

        totalInput.setEnabled(!active);
        batchInput.setEnabled(!active);
        cooldownInput.setEnabled(!active);
        for (int i = 0; i < speedGroup.getChildCount(); i++) {
            speedGroup.getChildAt(i).setEnabled(!active);
        }

        if (active) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private String statusLabel(JobSnapshot state) {
        if (state.isPaused()) return "일시정지";
        if ("running".equals(state.status)) {
            if ("count".equals(state.mode)) return "개수 확인 중";
            if ("waiting_reload".equals(state.phase)) return "Instagram 로딩 대기";
            if ("cooling".equals(state.phase)) return "작업 사이 휴식";
            return "정리 진행 중";
        }
        return switch (state.status) {
            case "completed" -> "완료";
            case "stopped" -> "중단됨";
            case "blocked" -> "Instagram 활동 제한";
            case "error" -> "오류";
            default -> "대기 중";
        };
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    270
            );
        }
    }

    @Override
    protected void onDestroy() {
        if (isFinishing() && controller != null && controller.state().isActive()) {
            controller.stop();
        }
        if (controller != null) controller.removeListener(this);
        if (controller != null && bridge != null) controller.detachBridge(bridge);
        if (bridge != null) bridge.close();
        super.onDestroy();
    }
}

package co.kr.lavalabs.instagramcleaner.mobile;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

import java.nio.charset.StandardCharsets;

import co.kr.lavalabs.instagramcleaner.common.BridgeContract;

public final class PhoneCommandService extends WearableListenerService {
    @Override
    public void onMessageReceived(MessageEvent event) {
        if (!BridgeContract.MESSAGE_COMMAND_PATH.equals(event.getPath())) return;
        String command = new String(event.getData(), StandardCharsets.UTF_8);
        CleanerController.get(this).handleRemoteCommand(command);
    }
}

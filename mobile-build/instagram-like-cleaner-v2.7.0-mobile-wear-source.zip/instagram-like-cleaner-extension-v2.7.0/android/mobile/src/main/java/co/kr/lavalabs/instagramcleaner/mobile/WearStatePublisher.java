package co.kr.lavalabs.instagramcleaner.mobile;

import android.content.Context;

import com.google.android.gms.wearable.DataClient;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;

import co.kr.lavalabs.instagramcleaner.common.BridgeContract;
import co.kr.lavalabs.instagramcleaner.common.JobSnapshot;

public final class WearStatePublisher {
    private final DataClient dataClient;

    public WearStatePublisher(Context context) {
        dataClient = Wearable.getDataClient(context.getApplicationContext());
    }

    public void publish(JobSnapshot snapshot) {
        PutDataMapRequest mapRequest = PutDataMapRequest.create(BridgeContract.DATA_STATE_PATH);
        DataMap map = mapRequest.getDataMap();
        map.putString("snapshot", snapshot.toJson());
        map.putLong("updatedAt", System.currentTimeMillis());
        PutDataRequest request = mapRequest.asPutDataRequest().setUrgent();
        dataClient.putDataItem(request);
    }
}

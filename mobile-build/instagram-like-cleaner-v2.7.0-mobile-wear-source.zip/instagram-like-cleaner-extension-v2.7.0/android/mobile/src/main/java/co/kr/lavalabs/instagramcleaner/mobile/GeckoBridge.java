package co.kr.lavalabs.instagramcleaner.mobile;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONException;
import org.json.JSONObject;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebExtension;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import co.kr.lavalabs.instagramcleaner.common.BridgeContract;

public final class GeckoBridge {
    public interface Listener {
        void onBridgeReady(boolean ready);
        void onEvent(@NonNull JSONObject message);
        void onBridgeError(@NonNull String message);
    }

    public interface Callback {
        void onResult(@NonNull JSONObject response);
    }

    private static GeckoRuntime runtime;

    private final GeckoSession session;
    private final Listener listener;
    private final Map<String, Callback> pending = new ConcurrentHashMap<>();
    private WebExtension.Port nativePort;

    public GeckoBridge(
            @NonNull Context context,
            @NonNull GeckoView view,
            @NonNull Listener listener
    ) {
        this.listener = listener;
        this.session = new GeckoSession();
        this.session.setContentDelegate(new GeckoSession.ContentDelegate() {});

        if (runtime == null) {
            runtime = GeckoRuntime.create(context.getApplicationContext());
        }

        session.open(runtime);
        view.setSession(session);
        installExtension();
    }

    private void installExtension() {
        WebExtension.PortDelegate portDelegate = new WebExtension.PortDelegate() {
            @Override
            public void onPortMessage(
                    @NonNull Object message,
                    @NonNull WebExtension.Port port
            ) {
                handlePortMessage(message);
            }

            @Override
            public void onDisconnect(@NonNull WebExtension.Port port) {
                if (nativePort == port) {
                    nativePort = null;
                    listener.onBridgeReady(false);
                }
            }
        };

        WebExtension.MessageDelegate messageDelegate = new WebExtension.MessageDelegate() {
            @Override
            public void onConnect(@NonNull WebExtension.Port port) {
                nativePort = port;
                nativePort.setDelegate(portDelegate);
                listener.onBridgeReady(true);
                sendCommand("HELLO", new JSONObject(), ignored -> {});
            }
        };

        runtime.getWebExtensionController()
                .ensureBuiltIn(
                        BridgeContract.EXTENSION_LOCATION,
                        BridgeContract.EXTENSION_ID
                )
                .accept(
                        extension -> {
                            extension.setMessageDelegate(
                                    messageDelegate,
                                    BridgeContract.NATIVE_APP_ID
                            );
                            session.loadUri(BridgeContract.LIKES_URL);
                        },
                        error -> listener.onBridgeError(
                                error.getMessage() == null
                                        ? "모바일 정리 엔진을 설치하지 못했습니다."
                                        : error.getMessage()
                        )
                );
    }

    private void handlePortMessage(@NonNull Object raw) {
        final JSONObject envelope;
        try {
            if (raw instanceof JSONObject) {
                envelope = (JSONObject) raw;
            } else {
                envelope = new JSONObject(String.valueOf(raw));
            }
        } catch (JSONException error) {
            listener.onBridgeError("정리 엔진에서 잘못된 응답을 받았습니다.");
            return;
        }

        String kind = envelope.optString("kind");
        if ("response".equals(kind)) {
            String requestId = envelope.optString("requestId");
            Callback callback = pending.remove(requestId);
            if (callback != null) {
                JSONObject response = envelope.optJSONObject("response");
                callback.onResult(response == null ? new JSONObject() : response);
            }
            return;
        }

        if ("event".equals(kind)) {
            JSONObject message = envelope.optJSONObject("message");
            if (message != null) listener.onEvent(message);
        }
    }

    public boolean isReady() {
        return nativePort != null;
    }

    public void loadLikesPage() {
        session.loadUri(BridgeContract.LIKES_URL);
    }

    public void sendCommand(
            @NonNull String type,
            @Nullable JSONObject options,
            @NonNull Callback callback
    ) {
        if (nativePort == null) {
            callback.onResult(errorResponse(
                    "브라우저 연결이 아직 준비되지 않았습니다. 잠시 후 다시 눌러주세요."
            ));
            return;
        }

        String requestId = UUID.randomUUID().toString();
        JSONObject request = new JSONObject();
        try {
            request.put("requestId", requestId);
            request.put("type", type);
            request.put("options", options == null ? new JSONObject() : options);
            pending.put(requestId, callback);
            nativePort.postMessage(request);
        } catch (JSONException | RuntimeException error) {
            pending.remove(requestId);
            callback.onResult(errorResponse(
                    error.getMessage() == null ? "명령을 전송하지 못했습니다." : error.getMessage()
            ));
        }
    }

    private static JSONObject errorResponse(String message) {
        JSONObject response = new JSONObject();
        try {
            response.put("ok", false);
            response.put("message", message);
        } catch (JSONException ignored) {
        }
        return response;
    }

    public void close() {
        nativePort = null;
        pending.clear();
        session.close();
    }
}

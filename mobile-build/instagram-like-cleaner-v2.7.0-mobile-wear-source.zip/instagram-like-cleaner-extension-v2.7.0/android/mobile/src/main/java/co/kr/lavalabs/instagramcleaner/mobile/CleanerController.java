package co.kr.lavalabs.instagramcleaner.mobile;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

import co.kr.lavalabs.instagramcleaner.common.BridgeContract;
import co.kr.lavalabs.instagramcleaner.common.JobSnapshot;

public final class CleanerController implements GeckoBridge.Listener {
    public interface Listener {
        void onStateChanged(@NonNull JobSnapshot snapshot);
    }

    private static final String PREFS = "cleaner_runtime";
    private static final String STATE_KEY = "snapshot";
    private static CleanerController instance;

    private final Context appContext;
    private final SharedPreferences preferences;
    private final WearStatePublisher wearPublisher;
    private final Set<Listener> listeners = new CopyOnWriteArraySet<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private JobSnapshot snapshot;
    private GeckoBridge bridge;

    private CleanerController(Context context) {
        appContext = context.getApplicationContext();
        preferences = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        snapshot = JobSnapshot.fromJson(preferences.getString(STATE_KEY, null));
        snapshot.bridgeReady = false;
        wearPublisher = new WearStatePublisher(appContext);
    }

    public static synchronized CleanerController get(Context context) {
        if (instance == null) instance = new CleanerController(context);
        return instance;
    }

    public void attachBridge(@NonNull GeckoBridge bridge) {
        this.bridge = bridge;
        update(current -> {
            current.bridgeReady = bridge.isReady();
            if (!current.isActive() && "idle".equals(current.status)) {
                current.message = "브라우저 엔진을 연결하고 있습니다.";
            }
        });
    }

    public void detachBridge(@NonNull GeckoBridge bridge) {
        if (this.bridge == bridge) {
            this.bridge = null;
            update(current -> current.bridgeReady = false);
        }
    }

    public void addListener(@NonNull Listener listener) {
        listeners.add(listener);
        listener.onStateChanged(snapshot.copy());
    }

    public void removeListener(@NonNull Listener listener) {
        listeners.remove(listener);
    }

    public JobSnapshot state() {
        return snapshot.copy();
    }

    public void openLikesPage() {
        GeckoBridge currentBridge = bridge;
        if (currentBridge == null) {
            fail("휴대폰 앱의 브라우저가 준비되지 않았습니다.");
            return;
        }
        currentBridge.loadLikesPage();
        currentBridge.sendCommand(
                BridgeContract.CMD_OPEN_LIKES,
                new JSONObject(),
                response -> {
                    if (!response.optBoolean("ok", false)) {
                        fail(response.optString("message", "좋아요 화면을 열지 못했습니다."));
                    }
                }
        );
    }

    public void checkPage(@NonNull GeckoBridge.Callback callback) {
        send(BridgeContract.CMD_CHECK_PAGE, new JSONObject(), callback);
    }

    public void startCount(@NonNull CleanerSettings settings) {
        settings.save(appContext);
        JSONObject options = speedOptions(settings.speedMode);
        begin("count", "좋아요 게시물 전체 개수를 확인합니다.");
        sendStart(BridgeContract.CMD_START_COUNT, options);
    }

    public void startPlan(@NonNull CleanerSettings settings) {
        settings.save(appContext);
        JSONArray plan = new JSONArray();
        int remaining = CleanerSettings.clamp(settings.total, 1, 10000);
        int batch = CleanerSettings.clamp(settings.batchSize, 1, 100);
        while (remaining > 0) {
            int amount = Math.min(batch, remaining);
            plan.put(amount);
            remaining -= amount;
        }

        JSONObject options = speedOptions(settings.speedMode);
        try {
            options.put("plan", plan);
            options.put("cooldownMs", CleanerSettings.clamp(settings.cooldownSeconds, 5, 3600) * 1000L);
            options.put("autoScroll", true);
            options.put("strategyMode", "custom");
        } catch (JSONException ignored) {
        }

        begin(
                "delete_plan",
                String.format("%,d개를 최대 %,d개씩 정리합니다.", settings.total, batch)
        );
        update(current -> {
            current.target = settings.total;
            current.maxBatches = plan.length();
        });
        sendStart(BridgeContract.CMD_START_PLAN, options);
    }

    public void startDeleteAll(@NonNull CleanerSettings settings) {
        settings.save(appContext);
        JSONObject options = speedOptions(settings.speedMode);
        try {
            options.put("batchSize", CleanerSettings.clamp(settings.batchSize, 1, 100));
            options.put("cooldownMs", CleanerSettings.clamp(settings.cooldownSeconds, 5, 3600) * 1000L);
            options.put("autoScroll", true);
        } catch (JSONException ignored) {
        }

        begin(
                "delete_all",
                String.format("%,d개씩 반복하며 좋아요가 없어질 때까지 정리합니다.", settings.batchSize)
        );
        update(current -> current.target = settings.batchSize);
        sendStart(BridgeContract.CMD_START_DELETE_ALL, options);
    }

    public void pause() {
        send(BridgeContract.CMD_PAUSE, new JSONObject(), response -> {
            if (response.optBoolean("ok", false)) {
                update(current -> {
                    current.status = "paused";
                    current.message = "작업을 일시정지했습니다.";
                });
            } else {
                fail(response.optString("message", "작업을 일시정지하지 못했습니다."));
            }
        });
    }

    public void resume() {
        send(BridgeContract.CMD_RESUME, new JSONObject(), response -> {
            if (response.optBoolean("ok", false)) {
                update(current -> {
                    current.status = "running";
                    current.message = "작업을 재개했습니다.";
                });
            } else {
                fail(response.optString("message", "작업을 재개하지 못했습니다."));
            }
        });
    }

    public void stop() {
        send(BridgeContract.CMD_STOP, new JSONObject(), response -> {
            update(current -> {
                current.status = "stopped";
                current.phase = "finished";
                current.selected = 0;
                current.message = response.optString(
                        "message",
                        String.format("작업을 중단했습니다. 누적 %,d개를 완료했습니다.", current.totalSuccess)
                );
            });
        });
    }

    public void handleRemoteCommand(@Nullable String command) {
        CleanerSettings settings = CleanerSettings.load(appContext);
        if (BridgeContract.REMOTE_START_DELETE_ALL.equals(command)) {
            startDeleteAll(settings);
        } else if (BridgeContract.REMOTE_PAUSE.equals(command)) {
            pause();
        } else if (BridgeContract.REMOTE_RESUME.equals(command)) {
            resume();
        } else if (BridgeContract.REMOTE_STOP.equals(command)) {
            stop();
        } else if (BridgeContract.REMOTE_OPEN_LIKES.equals(command)) {
            openLikesPage();
        }
    }

    private void begin(String mode, String message) {
        update(current -> {
            current.mode = mode;
            current.status = "running";
            current.phase = "preparing";
            current.message = message;
            current.target = 0;
            current.selected = 0;
            current.counted = 0;
            current.totalSuccess = 0;
            current.batchIndex = 0;
            current.maxBatches = 0;
            current.cooldownRemaining = 0;
        });
    }

    private void sendStart(String type, JSONObject options) {
        send(type, options, response -> {
            if (!response.optBoolean("ok", false)) {
                fail(response.optString("message", "정리 작업을 시작하지 못했습니다."));
            }
        });
    }

    private void send(
            @NonNull String type,
            @NonNull JSONObject options,
            @NonNull GeckoBridge.Callback callback
    ) {
        GeckoBridge currentBridge = bridge;
        if (currentBridge == null || !currentBridge.isReady()) {
            fail("휴대폰 앱을 열고 Instagram 브라우저 연결이 완료된 뒤 다시 실행해주세요.");
            callback.onResult(errorJson("브라우저 연결이 필요합니다."));
            return;
        }
        currentBridge.sendCommand(type, options, callback);
    }

    private static JSONObject speedOptions(String mode) {
        JSONObject options = new JSONObject();
        String safeMode = switch (mode) {
            case "safe", "fast" -> mode;
            default -> "balanced";
        };
        int click = "safe".equals(safeMode) ? 180 : "fast".equals(safeMode) ? 15 : 65;
        int scroll = "safe".equals(safeMode) ? 900 : "fast".equals(safeMode) ? 240 : 430;
        try {
            options.put("speedMode", safeMode);
            options.put("clickDelayMs", click);
            options.put("scrollWaitMs", scroll);
        } catch (JSONException ignored) {
        }
        return options;
    }

    private static JSONObject errorJson(String message) {
        JSONObject json = new JSONObject();
        try {
            json.put("ok", false);
            json.put("message", message);
        } catch (JSONException ignored) {
        }
        return json;
    }

    private void fail(String message) {
        update(current -> {
            current.status = "error";
            current.phase = "finished";
            current.message = message;
        });
    }

    @Override
    public void onBridgeReady(boolean ready) {
        update(current -> {
            current.bridgeReady = ready;
            if (ready && !current.isActive()) {
                current.message = "브라우저 연결 완료. Instagram 로그인 후 좋아요 화면을 열어주세요.";
            }
        });
    }

    @Override
    public void onEvent(@NonNull JSONObject message) {
        String type = message.optString("type");
        if (BridgeContract.EVENT_NATIVE_PROGRESS.equals(type)) {
            JSONObject progress = message.optJSONObject("progress");
            if (progress != null) applyNativeProgress(progress);
            return;
        }
        if (BridgeContract.EVENT_NATIVE_FINISHED.equals(type)) {
            JSONObject result = message.optJSONObject("result");
            if (result != null) applyNativeFinished(result);
            return;
        }
        if (BridgeContract.EVENT_COUNT_PROGRESS.equals(type)) {
            JSONObject progress = message.optJSONObject("progress");
            if (progress != null) {
                update(current -> {
                    current.mode = "count";
                    current.status = "running";
                    current.phase = progress.optString("phase", current.phase);
                    current.counted = Math.max(0, progress.optInt("counted", current.counted));
                    current.selected = current.counted;
                    current.message = progress.optString("message", current.message);
                });
            }
            return;
        }
        if (BridgeContract.EVENT_COUNT_FINISHED.equals(type)) {
            JSONObject result = message.optJSONObject("result");
            if (result != null) {
                update(current -> {
                    current.mode = "count";
                    current.counted = Math.max(0, result.optInt("counted", current.counted));
                    current.selected = current.counted;
                    current.status = result.optBoolean("ok", false) ? "completed" : result.optString("status", "error");
                    current.phase = "finished";
                    current.message = result.optString("message", "개수 확인을 종료했습니다.");
                });
            }
        }
    }

    @Override
    public void onBridgeError(@NonNull String message) {
        fail(message);
    }

    private void applyNativeProgress(JSONObject progress) {
        update(current -> {
            current.status = "running";
            current.phase = progress.optString("phase", current.phase);
            current.target = Math.max(0, progress.optInt("target", current.target));
            current.selected = Math.max(0, progress.optInt("selected", current.selected));
            current.batchIndex = Math.max(0, progress.optInt("batchIndex", current.batchIndex));
            current.maxBatches = Math.max(0, progress.optInt("maxBatches", current.maxBatches));
            current.totalSuccess = Math.max(0, progress.optInt("totalSuccess", current.totalSuccess));
            current.cooldownRemaining = Math.max(0, progress.optInt("cooldownRemaining", 0));
            current.message = progress.optString("message", current.message);
        });
    }

    private void applyNativeFinished(JSONObject result) {
        update(current -> {
            String resultStatus = result.optString("status", result.optBoolean("ok", false) ? "completed" : "error");
            current.status = "stopped".equals(resultStatus) ? "stopped" : result.optBoolean("ok", false) ? "completed" : resultStatus;
            current.phase = "finished";
            current.selected = Math.max(0, result.optInt("selected", 0));
            current.batchIndex = Math.max(0, result.optInt("batchIndex", current.batchIndex));
            current.totalSuccess = Math.max(
                    current.totalSuccess,
                    result.optInt("totalSuccess", result.optInt("success", current.totalSuccess))
            );
            current.message = result.optString("message", "정리 작업을 종료했습니다.");
        });
    }

    private interface Mutation {
        void apply(JobSnapshot snapshot);
    }

    private void update(Mutation mutation) {
        Runnable action = () -> {
            JobSnapshot next = snapshot.copy();
            mutation.apply(next);
            next.updatedAt = System.currentTimeMillis();
            snapshot = next;
            preferences.edit().putString(STATE_KEY, next.toJson()).apply();
            wearPublisher.publish(next);
            updateForegroundService(next);
            for (Listener listener : listeners) {
                listener.onStateChanged(next.copy());
            }
        };

        if (Looper.myLooper() == Looper.getMainLooper()) action.run();
        else mainHandler.post(action);
    }

    private void updateForegroundService(JobSnapshot current) {
        Intent intent = new Intent(appContext, CleanupForegroundService.class);
        if (current.isActive()) {
            intent.setAction(CleanupForegroundService.ACTION_REFRESH);
            try {
                ContextCompat.startForegroundService(appContext, intent);
            } catch (RuntimeException ignored) {
            }
        } else {
            try {
                appContext.stopService(intent);
            } catch (RuntimeException ignored) {
            }
        }
    }
}

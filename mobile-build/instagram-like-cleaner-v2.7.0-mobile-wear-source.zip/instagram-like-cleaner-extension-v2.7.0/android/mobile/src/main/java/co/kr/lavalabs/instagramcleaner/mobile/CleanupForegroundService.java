package co.kr.lavalabs.instagramcleaner.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import co.kr.lavalabs.instagramcleaner.common.JobSnapshot;

public final class CleanupForegroundService extends Service implements CleanerController.Listener {
    public static final String ACTION_REFRESH = "cleaner.action.REFRESH";
    public static final String ACTION_PAUSE = "cleaner.action.PAUSE";
    public static final String ACTION_RESUME = "cleaner.action.RESUME";
    public static final String ACTION_STOP = "cleaner.action.STOP";

    private static final String CHANNEL_ID = "instagram-cleaner-running";
    private static final int NOTIFICATION_ID = 270;
    private CleanerController controller;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        controller = CleanerController.get(this);
        controller.addListener(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_REFRESH : intent.getAction();
        if (ACTION_PAUSE.equals(action)) controller.pause();
        else if (ACTION_RESUME.equals(action)) controller.resume();
        else if (ACTION_STOP.equals(action)) controller.stop();

        JobSnapshot snapshot = controller.state();
        startForeground(NOTIFICATION_ID, buildNotification(snapshot));
        return START_NOT_STICKY;
    }

    @Override
    public void onStateChanged(JobSnapshot snapshot) {
        if (!snapshot.isActive()) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return;
        }
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.notify(NOTIFICATION_ID, buildNotification(snapshot));
    }

    private Notification buildNotification(JobSnapshot snapshot) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this,
                10,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String pauseAction = snapshot.isPaused() ? ACTION_RESUME : ACTION_PAUSE;
        String pauseLabel = snapshot.isPaused() ? "재개" : "일시정지";
        PendingIntent pausePending = servicePending(pauseAction, 11);
        PendingIntent stopPending = servicePending(ACTION_STOP, 12);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle(statusTitle(snapshot))
                .setContentText(snapshot.message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(snapshot.message))
                .setContentIntent(openPending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_PROGRESS)
                .addAction(0, pauseLabel, pausePending)
                .addAction(0, "중지", stopPending);

        if ("count".equals(snapshot.mode) || snapshot.target <= 0) {
            builder.setProgress(0, 0, true);
        } else {
            builder.setProgress(100, snapshot.progressPercent(), false);
        }
        return builder.build();
    }

    private PendingIntent servicePending(String action, int requestCode) {
        Intent intent = new Intent(this, CleanupForegroundService.class).setAction(action);
        return PendingIntent.getService(
                this,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private String statusTitle(JobSnapshot snapshot) {
        if (snapshot.isPaused()) return "Instagram 좋아요 정리 일시정지";
        if ("count".equals(snapshot.mode)) return "Instagram 좋아요 개수 확인 중";
        return String.format("Instagram 좋아요 정리 중 · %,d개 완료", snapshot.totalSuccess);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                getString(co.kr.lavalabs.instagramcleaner.mobile.R.string.notification_channel),
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("사용자가 시작한 좋아요 정리 작업의 진행 상태와 제어 버튼을 표시합니다.");
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    @Override
    public void onDestroy() {
        if (controller != null) controller.removeListener(this);
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

package co.kr.lavalabs.instagramcleaner.mobile;

import android.content.Context;
import android.content.SharedPreferences;

public final class CleanerSettings {
    private static final String PREFS = "cleaner_settings";

    public int total = 100;
    public int batchSize = 100;
    public int cooldownSeconds = 60;
    public String speedMode = "balanced";

    public static CleanerSettings load(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        CleanerSettings settings = new CleanerSettings();
        settings.total = clamp(prefs.getInt("total", 100), 1, 10000);
        settings.batchSize = clamp(prefs.getInt("batchSize", 100), 1, 100);
        settings.cooldownSeconds = clamp(prefs.getInt("cooldownSeconds", 60), 5, 3600);
        settings.speedMode = prefs.getString("speedMode", "balanced");
        return settings;
    }

    public void save(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putInt("total", clamp(total, 1, 10000))
                .putInt("batchSize", clamp(batchSize, 1, 100))
                .putInt("cooldownSeconds", clamp(cooldownSeconds, 5, 3600))
                .putString("speedMode", speedMode)
                .apply();
    }

    public static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}

# Android · 태블릿 · Galaxy Watch 구현

이 폴더는 기존 Chrome 확장 프로그램 v2.7.0의 실제 DOM 탐색 및 삭제 엔진을 그대로 재사용해 Android와 Wear OS로 확장한 첫 구현입니다.

## 구성

- `shared-engine/geckoview-extension/`
  - Chrome 확장의 `content-core.js`, `content.js` 로직을 재사용하며 GeckoView에서는 Promise 기반 `browser.runtime` 네임스페이스만 적용합니다.
  - `background.js`가 GeckoView WebExtension과 Android 앱 사이를 연결합니다.
- `android/mobile/`
  - 휴대폰, Galaxy Fold, Android 태블릿용 앱입니다.
  - GeckoView 안에서 Instagram에 직접 로그인하고 좋아요 화면을 엽니다.
  - 개수 확인, 설정 수량 정리, 전체 삭제, 일시정지, 재개, 완전 중지를 지원합니다.
  - 600dp 이상 화면에서는 Instagram과 제어판이 좌우 2열로 표시됩니다.
- `android/wear/`
  - Galaxy Watch 8 등 Wear OS용 리모컨입니다.
  - 휴대폰 앱에 전체 삭제 시작, 일시정지, 재개, 완전 중지 명령을 보냅니다.
  - 휴대폰에서 전송한 진행 상태와 누적 완료 수를 표시합니다.
- `android/common/`
  - 휴대폰과 워치가 함께 쓰는 명령 경로와 상태 모델입니다.

## 빌드

1. Android Studio에서 `android` 폴더를 엽니다.
2. JDK 17 이상을 선택합니다.
3. Gradle 동기화를 실행합니다.
4. 휴대폰에는 `mobile`, Galaxy Watch에는 `wear` 실행 구성을 설치합니다.
5. 두 기기는 같은 Google 계정 및 Wear OS 페어링 상태여야 합니다.

GeckoView는 Mozilla Maven 저장소에서 안정 채널 최신 릴리스를 받도록 설정했습니다. 실제 배포 전에는 `android/gradle.properties`의 `geckoviewVersion`을 빌드에 검증한 고정 버전으로 바꾸는 것이 좋습니다.

## 사용 순서

1. 휴대폰 앱을 실행합니다.
2. 앱 안의 Instagram 화면에서 직접 로그인합니다.
3. `좋아요 열기`를 눌러 좋아요 활동 화면으로 이동합니다.
4. 처리 수량, 묶음 수량, 휴식 시간, 속도를 선택합니다.
5. 개수 확인, 설정 수량 정리 또는 전체 삭제를 실행합니다.
6. Galaxy Watch 앱에서는 같은 작업을 일시정지·재개·중지하거나 저장된 설정으로 전체 삭제를 시작할 수 있습니다.

## 보안과 실행 조건

- Instagram 비밀번호와 OTP는 앱 코드에서 요청하거나 저장하지 않습니다.
- 로그인 정보는 GeckoView의 Instagram 웹 세션 안에서만 관리됩니다.
- 별도 Lava Labs 서버로 Instagram 계정 또는 게시물 정보를 전송하지 않습니다.
- 실제 DOM 자동화는 화면이 켜져 있고 휴대폰 앱이 전면에 있을 때 가장 안정적입니다.
- 워치만으로 작업 엔진을 실행하지 않습니다. 휴대폰 앱의 GeckoView가 실제 처리를 담당합니다.

## 검증 범위

현재 작업 환경에는 Android SDK와 Gradle 배포판이 없어 APK 컴파일 및 실기기 설치 검증은 수행하지 못했습니다. 대신 다음을 검증했습니다.

- 원본 및 GeckoView용 JavaScript 구문 검사
- 처리 계획 단위 테스트
- Android–WebExtension 메시지 라우팅 단위 테스트
- Android 리소스 XML 파싱
- JSON 매니페스트 파싱
- 최종 ZIP 무결성 검사

실기기 검증 시에는 Instagram 로그인, 선택 버튼 탐지, 전체 삭제 1회, 로딩 완료 대기, 워치 일시정지·재개 순서로 확인해야 합니다.
